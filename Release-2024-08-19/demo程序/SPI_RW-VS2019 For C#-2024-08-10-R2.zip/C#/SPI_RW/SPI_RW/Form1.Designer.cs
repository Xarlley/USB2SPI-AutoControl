﻿namespace SPI_RW
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.TextBox8 = new System.Windows.Forms.TextBox();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.CheckBox4 = new System.Windows.Forms.CheckBox();
            this.CheckBox3 = new System.Windows.Forms.CheckBox();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.TextBox10 = new System.Windows.Forms.TextBox();
            this.TextBox11 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Button10 = new System.Windows.Forms.Button();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.ComboBox2 = new System.Windows.Forms.ComboBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.SaveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.OpenFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.TextBox9 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.TextBox14 = new System.Windows.Forms.TextBox();
            this.ComboBox5 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.ComboBox4 = new System.Windows.Forms.ComboBox();
            this.TextBox13 = new System.Windows.Forms.TextBox();
            this.TextBox12 = new System.Windows.Forms.TextBox();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.Button15 = new System.Windows.Forms.Button();
            this.ComboBox3 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Button16 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.GroupBox3.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.Label12);
            this.GroupBox3.Controls.Add(this.Label13);
            this.GroupBox3.Controls.Add(this.TextBox7);
            this.GroupBox3.Controls.Add(this.Label10);
            this.GroupBox3.Controls.Add(this.Button7);
            this.GroupBox3.Controls.Add(this.Button8);
            this.GroupBox3.Controls.Add(this.Button9);
            this.GroupBox3.Controls.Add(this.TextBox8);
            this.GroupBox3.Location = new System.Drawing.Point(480, 138);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(462, 308);
            this.GroupBox3.TabIndex = 14;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Write";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(294, 54);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(11, 12);
            this.Label12.TabIndex = 20;
            this.Label12.Text = "0";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(205, 54);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(83, 12);
            this.Label13.TabIndex = 19;
            this.Label13.Text = "Buff counter:";
            // 
            // TextBox7
            // 
            this.TextBox7.Location = new System.Drawing.Point(79, 22);
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new System.Drawing.Size(107, 21);
            this.TextBox7.TabIndex = 15;
            this.TextBox7.Text = "00";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(20, 25);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(53, 12);
            this.Label10.TabIndex = 13;
            this.Label10.Text = "Command:";
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(339, 20);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(74, 23);
            this.Button7.TabIndex = 12;
            this.Button7.Text = "Load from";
            this.Button7.UseVisualStyleBackColor = true;
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(273, 20);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(60, 23);
            this.Button8.TabIndex = 11;
            this.Button8.Text = "Clear";
            this.Button8.UseVisualStyleBackColor = true;
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(192, 20);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(75, 23);
            this.Button9.TabIndex = 10;
            this.Button9.Text = "Do Write";
            this.Button9.UseVisualStyleBackColor = true;
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // TextBox8
            // 
            this.TextBox8.Location = new System.Drawing.Point(14, 72);
            this.TextBox8.Multiline = true;
            this.TextBox8.Name = "TextBox8";
            this.TextBox8.ReadOnly = true;
            this.TextBox8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBox8.Size = new System.Drawing.Size(442, 230);
            this.TextBox8.TabIndex = 9;
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(851, 99);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(91, 23);
            this.Button3.TabIndex = 13;
            this.Button3.Text = "About";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(851, 67);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(91, 23);
            this.Button2.TabIndex = 12;
            this.Button2.Text = "SPI Test";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(851, 13);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(91, 23);
            this.Button1.TabIndex = 11;
            this.Button1.Text = "conntect";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.Label9);
            this.GroupBox4.Controls.Add(this.TextBox5);
            this.GroupBox4.Controls.Add(this.TextBox4);
            this.GroupBox4.Controls.Add(this.Label8);
            this.GroupBox4.Controls.Add(this.Label7);
            this.GroupBox4.Controls.Add(this.Button6);
            this.GroupBox4.Controls.Add(this.Button5);
            this.GroupBox4.Controls.Add(this.Button4);
            this.GroupBox4.Controls.Add(this.TextBox3);
            this.GroupBox4.Location = new System.Drawing.Point(12, 138);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(452, 308);
            this.GroupBox4.TabIndex = 10;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Read";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(337, 53);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(11, 12);
            this.Label11.TabIndex = 18;
            this.Label11.Text = "0";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(248, 53);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(83, 12);
            this.Label9.TabIndex = 17;
            this.Label9.Text = "Buff counter:";
            // 
            // TextBox5
            // 
            this.TextBox5.Location = new System.Drawing.Point(79, 45);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new System.Drawing.Size(45, 21);
            this.TextBox5.TabIndex = 16;
            this.TextBox5.Text = "16";
            // 
            // TextBox4
            // 
            this.TextBox4.Location = new System.Drawing.Point(79, 22);
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new System.Drawing.Size(112, 21);
            this.TextBox4.TabIndex = 15;
            this.TextBox4.Text = "00";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(20, 49);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(47, 12);
            this.Label8.TabIndex = 14;
            this.Label8.Text = "Length:";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(20, 25);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(53, 12);
            this.Label7.TabIndex = 13;
            this.Label7.Text = "Command:";
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(339, 20);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(60, 23);
            this.Button6.TabIndex = 12;
            this.Button6.Text = "Save as";
            this.Button6.UseVisualStyleBackColor = true;
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(273, 20);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(60, 23);
            this.Button5.TabIndex = 11;
            this.Button5.Text = "Clear";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(207, 20);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(60, 23);
            this.Button4.TabIndex = 10;
            this.Button4.Text = "Do Read";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(14, 72);
            this.TextBox3.Multiline = true;
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.ReadOnly = true;
            this.TextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBox3.Size = new System.Drawing.Size(432, 230);
            this.TextBox3.TabIndex = 9;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.CheckBox4);
            this.GroupBox1.Controls.Add(this.CheckBox3);
            this.GroupBox1.Controls.Add(this.CheckBox2);
            this.GroupBox1.Controls.Add(this.TextBox10);
            this.GroupBox1.Controls.Add(this.TextBox11);
            this.GroupBox1.Controls.Add(this.label4);
            this.GroupBox1.Controls.Add(this.Button10);
            this.GroupBox1.Controls.Add(this.Label6);
            this.GroupBox1.Controls.Add(this.Label5);
            this.GroupBox1.Controls.Add(this.TextBox2);
            this.GroupBox1.Controls.Add(this.CheckBox1);
            this.GroupBox1.Controls.Add(this.ComboBox2);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.ComboBox1);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Controls.Add(this.TextBox1);
            this.GroupBox1.Location = new System.Drawing.Point(12, 12);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(358, 109);
            this.GroupBox1.TabIndex = 9;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "SPI Setting";
            // 
            // CheckBox4
            // 
            this.CheckBox4.AutoSize = true;
            this.CheckBox4.Location = new System.Drawing.Point(189, 83);
            this.CheckBox4.Name = "CheckBox4";
            this.CheckBox4.Size = new System.Drawing.Size(72, 16);
            this.CheckBox4.TabIndex = 17;
            this.CheckBox4.Text = "Directed";
            this.CheckBox4.UseVisualStyleBackColor = true;
            // 
            // CheckBox3
            // 
            this.CheckBox3.AutoSize = true;
            this.CheckBox3.Location = new System.Drawing.Point(139, 83);
            this.CheckBox3.Name = "CheckBox3";
            this.CheckBox3.Size = new System.Drawing.Size(42, 16);
            this.CheckBox3.TabIndex = 16;
            this.CheckBox3.Text = "LSB";
            this.CheckBox3.UseVisualStyleBackColor = true;
            // 
            // CheckBox2
            // 
            this.CheckBox2.AutoSize = true;
            this.CheckBox2.Location = new System.Drawing.Point(74, 83);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(60, 16);
            this.CheckBox2.TabIndex = 15;
            this.CheckBox2.Text = "Slaver";
            this.CheckBox2.UseVisualStyleBackColor = true;
            // 
            // TextBox10
            // 
            this.TextBox10.Location = new System.Drawing.Point(309, 47);
            this.TextBox10.Name = "TextBox10";
            this.TextBox10.Size = new System.Drawing.Size(37, 21);
            this.TextBox10.TabIndex = 14;
            this.TextBox10.Text = "0";
            // 
            // TextBox11
            // 
            this.TextBox11.Location = new System.Drawing.Point(309, 19);
            this.TextBox11.Name = "TextBox11";
            this.TextBox11.Size = new System.Drawing.Size(37, 21);
            this.TextBox11.TabIndex = 13;
            this.TextBox11.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(126, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "CommandEnd:";
            // 
            // Button10
            // 
            this.Button10.Location = new System.Drawing.Point(271, 79);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(75, 23);
            this.Button10.TabIndex = 11;
            this.Button10.Text = "Set";
            this.Button10.UseVisualStyleBackColor = true;
            this.Button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(240, 53);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(59, 12);
            this.Label6.TabIndex = 10;
            this.Label6.Text = "Data End:";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(240, 25);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(71, 12);
            this.Label5.TabIndex = 9;
            this.Label5.Text = "Each Frame:";
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(198, 50);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(37, 21);
            this.TextBox2.TabIndex = 8;
            this.TextBox2.Text = "0";
            // 
            // CheckBox1
            // 
            this.CheckBox1.AutoSize = true;
            this.CheckBox1.Location = new System.Drawing.Point(14, 83);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(54, 16);
            this.CheckBox1.TabIndex = 6;
            this.CheckBox1.Text = "16bit";
            this.CheckBox1.UseVisualStyleBackColor = true;
            // 
            // ComboBox2
            // 
            this.ComboBox2.FormattingEnabled = true;
            this.ComboBox2.Items.AddRange(new object[] {
            "Mode0 (00)",
            "Mode1 (01)",
            "Mode2 (10)",
            "Mode3 (11)"});
            this.ComboBox2.Location = new System.Drawing.Point(49, 50);
            this.ComboBox2.Name = "ComboBox2";
            this.ComboBox2.Size = new System.Drawing.Size(75, 20);
            this.ComboBox2.TabIndex = 5;
            this.ComboBox2.Text = "Mode0(00)";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(12, 53);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(35, 12);
            this.Label3.TabIndex = 4;
            this.Label3.Text = "Mode:";
            // 
            // ComboBox1
            // 
            this.ComboBox1.DisplayMember = "1";
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "60/2M",
            "60/4M",
            "60/8M",
            "60/16M",
            "60/32M",
            "60/64M",
            "60/128M",
            "60/256M"});
            this.ComboBox1.Location = new System.Drawing.Point(49, 22);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(75, 20);
            this.ComboBox1.TabIndex = 3;
            this.ComboBox1.Text = "60/16M";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(12, 25);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(29, 12);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Fre:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(129, 25);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(71, 12);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "CS Get Low:";
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(198, 22);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(37, 21);
            this.TextBox1.TabIndex = 0;
            this.TextBox1.Text = "0";
            // 
            // OpenFileDialog1
            // 
            this.OpenFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TextBox6);
            this.groupBox2.Controls.Add(this.Button13);
            this.groupBox2.Controls.Add(this.Button11);
            this.groupBox2.Controls.Add(this.TextBox9);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(377, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(161, 110);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "GPIO";
            // 
            // TextBox6
            // 
            this.TextBox6.Location = new System.Drawing.Point(56, 26);
            this.TextBox6.MaxLength = 2;
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new System.Drawing.Size(41, 21);
            this.TextBox6.TabIndex = 10;
            this.TextBox6.Text = "0000";
            // 
            // Button13
            // 
            this.Button13.Location = new System.Drawing.Point(103, 57);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(48, 23);
            this.Button13.TabIndex = 15;
            this.Button13.Text = "Write";
            this.Button13.UseVisualStyleBackColor = true;
            this.Button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Button11
            // 
            this.Button11.Location = new System.Drawing.Point(103, 27);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(48, 23);
            this.Button11.TabIndex = 13;
            this.Button11.Text = "Set";
            this.Button11.UseVisualStyleBackColor = true;
            this.Button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // TextBox9
            // 
            this.TextBox9.Location = new System.Drawing.Point(56, 57);
            this.TextBox9.MaxLength = 2;
            this.TextBox9.Name = "TextBox9";
            this.TextBox9.Size = new System.Drawing.Size(41, 21);
            this.TextBox9.TabIndex = 11;
            this.TextBox9.Text = "00";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 62);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 9;
            this.label15.Text = "Value:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 8;
            this.label14.Text = "Config:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.TextBox14);
            this.groupBox5.Controls.Add(this.ComboBox5);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.ComboBox4);
            this.groupBox5.Controls.Add(this.TextBox13);
            this.groupBox5.Controls.Add(this.TextBox12);
            this.groupBox5.Controls.Add(this.RadioButton2);
            this.groupBox5.Controls.Add(this.RadioButton1);
            this.groupBox5.Controls.Add(this.Button15);
            this.groupBox5.Controls.Add(this.ComboBox3);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Location = new System.Drawing.Point(544, 14);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(293, 108);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Trigger";
            // 
            // TextBox14
            // 
            this.TextBox14.Location = new System.Drawing.Point(230, 48);
            this.TextBox14.MaxLength = 0;
            this.TextBox14.Name = "TextBox14";
            this.TextBox14.Size = new System.Drawing.Size(41, 21);
            this.TextBox14.TabIndex = 25;
            this.TextBox14.Text = "00";
            // 
            // ComboBox5
            // 
            this.ComboBox5.FormattingEnabled = true;
            this.ComboBox5.Items.AddRange(new object[] {
            "Read",
            "Read after Write",
            "Write after Read"});
            this.ComboBox5.Location = new System.Drawing.Point(74, 77);
            this.ComboBox5.Name = "ComboBox5";
            this.ComboBox5.Size = new System.Drawing.Size(82, 20);
            this.ComboBox5.TabIndex = 24;
            this.ComboBox5.Text = "Mode0(00)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(20, 79);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 23;
            this.label18.Text = "Actions:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(165, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 22;
            this.label17.Text = "TrigCnt:";
            // 
            // ComboBox4
            // 
            this.ComboBox4.FormattingEnabled = true;
            this.ComboBox4.Items.AddRange(new object[] {
            "s",
            "ms",
            "us"});
            this.ComboBox4.Location = new System.Drawing.Point(106, 48);
            this.ComboBox4.Name = "ComboBox4";
            this.ComboBox4.Size = new System.Drawing.Size(50, 20);
            this.ComboBox4.TabIndex = 21;
            this.ComboBox4.Text = "Mode0(00)";
            // 
            // TextBox13
            // 
            this.TextBox13.Location = new System.Drawing.Point(71, 47);
            this.TextBox13.MaxLength = 0;
            this.TextBox13.Name = "TextBox13";
            this.TextBox13.Size = new System.Drawing.Size(31, 21);
            this.TextBox13.TabIndex = 20;
            this.TextBox13.Text = "00";
            // 
            // TextBox12
            // 
            this.TextBox12.Location = new System.Drawing.Point(230, 22);
            this.TextBox12.MaxLength = 4;
            this.TextBox12.Name = "TextBox12";
            this.TextBox12.Size = new System.Drawing.Size(41, 21);
            this.TextBox12.TabIndex = 19;
            this.TextBox12.Text = "00";
            // 
            // RadioButton2
            // 
            this.RadioButton2.AutoSize = true;
            this.RadioButton2.Location = new System.Drawing.Point(14, 48);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(53, 16);
            this.RadioButton2.TabIndex = 18;
            this.RadioButton2.TabStop = true;
            this.RadioButton2.Text = "Timer";
            this.RadioButton2.UseVisualStyleBackColor = true;
            // 
            // RadioButton1
            // 
            this.RadioButton1.AutoSize = true;
            this.RadioButton1.Location = new System.Drawing.Point(14, 23);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(47, 16);
            this.RadioButton1.TabIndex = 17;
            this.RadioButton1.TabStop = true;
            this.RadioButton1.Text = "GPIO";
            this.RadioButton1.UseVisualStyleBackColor = true;
            // 
            // Button15
            // 
            this.Button15.Location = new System.Drawing.Point(210, 78);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(48, 23);
            this.Button15.TabIndex = 14;
            this.Button15.Text = "Set";
            this.Button15.UseVisualStyleBackColor = true;
            this.Button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // ComboBox3
            // 
            this.ComboBox3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ComboBox3.FormattingEnabled = true;
            this.ComboBox3.Items.AddRange(new object[] {
            "Raising Edge",
            "Falling Edge",
            "Raising&Falling"});
            this.ComboBox3.Location = new System.Drawing.Point(71, 22);
            this.ComboBox3.Name = "ComboBox3";
            this.ComboBox3.Size = new System.Drawing.Size(85, 20);
            this.ComboBox3.TabIndex = 10;
            this.ComboBox3.Text = "Mode0(00)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(165, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 9;
            this.label16.Text = "TrigSize:";
            // 
            // Button16
            // 
            this.Button16.Location = new System.Drawing.Point(851, 39);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(91, 23);
            this.Button16.TabIndex = 15;
            this.Button16.Text = "Start Trig";
            this.Button16.UseVisualStyleBackColor = true;
            this.Button16.Click += new System.EventHandler(this.Button16_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 452);
            this.Controls.Add(this.Button16);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.GroupBox1);
            this.Name = "Form1";
            this.Text = "SPI_RW";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.TextBox TextBox7;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.TextBox TextBox8;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox TextBox5;
        internal System.Windows.Forms.TextBox TextBox4;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.TextBox TextBox3;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.ComboBox ComboBox2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog1;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog1;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.Button Button13;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.TextBox TextBox9;
        internal System.Windows.Forms.TextBox TextBox6;
        internal System.Windows.Forms.Label label15;
        internal System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox5;
        internal System.Windows.Forms.Button Button16;
        internal System.Windows.Forms.Button Button15;
        internal System.Windows.Forms.ComboBox ComboBox3;
        internal System.Windows.Forms.Label label16;
        internal System.Windows.Forms.CheckBox CheckBox4;
        internal System.Windows.Forms.CheckBox CheckBox3;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.TextBox TextBox10;
        internal System.Windows.Forms.TextBox TextBox11;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton RadioButton2;
        private System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.TextBox TextBox14;
        internal System.Windows.Forms.ComboBox ComboBox5;
        internal System.Windows.Forms.Label label18;
        internal System.Windows.Forms.Label label17;
        internal System.Windows.Forms.ComboBox ComboBox4;
        internal System.Windows.Forms.TextBox TextBox13;
        internal System.Windows.Forms.TextBox TextBox12;
        private System.Windows.Forms.Timer timer1;
    }
}

