﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

public delegate bool CallBack(byte bIndex, UInt32 dwUSBStatus);

struct SPI_CONFIG
 {
 	/* 
 	 wSPIConfig:  
 	   bit15  for SPI R/W access mode         1- Directed    , 0- DMA
     bit12  for SPI Frame length:             1- 16 bit      , 0- 8 bit
     bit7   for SPI Frame format:             1- LSB first   , 0- MSB first
     bit5~3 for SPI frequency devide factor:  SPI frequecy = SYSCLK / ( factor + 1)
     bit2   for SPI mode:                     1- Master      , 0- Slaver
     bit1   for SPI CLK level when idle:      1- High        , 0- Low
     bit0   for SPI CLK capture:              1- the Second edge,0- the First edge                   
 	*/
  public UInt16 wSPIConfig;       
  /* the delay time after CS becomes low, unit us  */
  public UInt16 wDelayCSLow;    
  /* the delay time after sends command, unit us */
  public UInt16 wDelayComEnd;      
  /* the delay time after sends or receives a frame */
  public UInt16 wDelayFrameEnd;   
  /* the delay time after sends oe receives all the data */
  public UInt16 wDelayDataEnd;
  public UInt16 wReserved;         //unused
 }


[StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)] 
 struct TRIG_CONFIG
 {
 	/*
 	  byTrigCon:
 	    bit7   for Trig staus:                  1- Trig opened,  0- Trig closed
 	    bit0   got Trig type:                   1- IO Trig,      0- Timer Trig 	       
 	*/
    public byte byTrigCon;        
	/*
	  byIOTrigOptions:  for IO Trig type
	     0-- raising edge
	     1-- falling edge
	     2-- raising or falling edge
	*/
    public byte byIOTrigOptions;

    public byte byUnused;
	
	/*
	 byActions: the action after trigged
	 0: Execute Read
	 1: Execute write and read
	 2: Execute read and write
	*/
    public byte byActions;       
  /* dwPeriod: Timer trig period, unit us */
    public UInt32 dwPeriod;        
	/* byRCmdSize: read commamd size, in bytes */
   public byte byRCmdSize;       
  /* byWCmdSize: write commamd size, in bytes */
   public byte byWCmdSize;      
	/* byReadCmd: read commad buff */
  [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
   public byte[] byReadCmd;
	/* byWriteCmd: write commad buff */  
  [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
  public byte[] byWriteCmd;   
  /* wReadSize: read data size, must be less than 3072 */
  public UInt16 wReadSize;        
	/* wTrigSize: trig buff size, must be less than 3072
	   it will send data to upport while read data is equal to wTrigSize
	 */
    public UInt16 wTrigSize;
    public UInt16 wUnused;
  /* dwTrigCnt: current trig counter */
    public UInt32 dwTrigCnt;        
  /* dwMaxCnt: Max Enabled trig number , trig will exit if dwTrigCnt is equal to dwMaxCnt */
    public UInt32 dwMaxCnt;         
 }

namespace SPI_RW
{
    class DLLImport
    {
        /*--------------------------------DLL function import---------------------------------*/


        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SetUSBNotify(bool bLoged, CallBack pUSB_CallBack);       

        [DllImport("M3F20xm.dll")]
        public static extern byte M3F20xm_OpenDevice();
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_Verify(byte byIndex,ref byte pResult);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_CloseDevice(byte bIndex);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_ResetDevice(byte bIndex);
        [DllImport("M3F20xm.dll")]
        public static extern byte M3F20xm_OpenDeviceByNumber(StringBuilder pSerial);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_CloseDeviceByNumber(StringBuilder pSerial);
        [DllImport("M3F20xm.dll")]
        public static extern byte M3F20xm_GetSerialNo(byte bIndex, StringBuilder pSerial);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GetVersion(byte bIndex, byte bType, StringBuilder pVersion);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_DFUMode(byte byIndex);

       

        /*here are SPI functions*/
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SPIGetConfig(byte bIndex, ref SPI_CONFIG pCfg);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SPISetConfig(byte bIndex, ref SPI_CONFIG pCfg);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SPITransfer(byte bIndex, byte[] lpWriteBuffer, byte[] lpReadBuffer, UInt16 wBuffSize,UInt32 dwTimeout);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SPIRead(byte bIndex, byte[] byCmd, byte byComSize, byte[] byReadData, UInt32 dwReadSize, UInt32 dwTimeout);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_SPIWrite(byte bIndex, byte[] byCmd, byte byComSize, byte[] byWriteData, UInt32 dwWriteSize, UInt32 dwTimeout);

        /*here GPIO function*/
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GPIOGetConfig(byte bIndex, ref UInt32 pdwValue);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GPIOSetConfig(byte bIndex, UInt32 dwValue);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GPIORead(byte bIndex, ref byte pbyValue);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GPIOWrite(byte bIndex, byte byValue, byte byMask);  
       

        /*here are trig function*/
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_TrigGetConfig(byte bIndex, ref TRIG_CONFIG pCfg);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_TrigSetConfig(byte bIndex, ref TRIG_CONFIG pCfg);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_EnableTrig(byte bIndex, byte byOn);

        /*here are the buff function*/
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_BuffRead(byte byIndex,UInt16 wAddr,byte[] lpBuffer,UInt16 wBuffSize,UInt32 dwTimeout);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_BuffWrite(byte byIndex, UInt16 wAddr, byte[] lpBuffer, UInt16 wBuffSize, UInt32 dwTimeout);

        /*here are the FIFO function*/
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_InitFIFO(byte byIndex);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_ReadFIFO(byte byIndex, byte[] lpBuffer, UInt32 dwBuffSize, ref UInt32 pdwRealSize);
        [DllImport("M3F20xm.dll")]
        public static extern bool M3F20xm_GetFIFOLeft(byte byIndex, ref UInt32 pdwBuffsize);
        /*--------------------------------End---------------------------------*/
    }
}
