﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace SPI_RW
{
    public partial class Form1 : Form
    {
    //don't modify below define
     public const UInt32  USB2SPI_BUFFSIZE = 3072;
     public const UInt32  USB_POLL_SIZE    = (64 * 1024);   
     public const UInt32  INFINITE         = 0xFFFFFFFF;  // Infinite timeout
     public const UInt32  MAX_DMA_RW_SIZE  = (2 * 1024 * 1024);
     public const UInt32  MAX_DIR_RW_SIZE = (48 * 1024);

     public const UInt16 DIR_BIT = 0x8000;
     public const UInt16 DATASIZE_BIT = 0x0800;
     public const UInt16 ORDER_BIT = 0x0080;
     public const UInt16 FREQUENCY_BIT = 0x0038;
     public const UInt16 MODE_BIT = 0x0004;
     public const UInt16 CPOL_BIT = 0x0002;
     public const UInt16 CPHA_BIT = 0x0001;

    byte byDevIndex;
    StringBuilder serialNo;
    SPI_CONFIG spiCfg;
    TRIG_CONFIG trigCfg;
    int readCnt, writeCnt;
    UInt32 gpioCfg;
    byte gpioValue;
    byte verified;
    UInt32 dwReadSize;
    public Form1()
    {
        InitializeComponent();
    }
    public void UpdateController()
    {
        string temp;
        ComboBox1.SelectedIndex = (spiCfg.wSPIConfig & FREQUENCY_BIT) >> 3;
        ComboBox2.SelectedIndex = spiCfg.wSPIConfig & 0x03;

      //  ComboBox3.SelectedIndex = 
        temp = spiCfg.wDelayCSLow.ToString();
        TextBox1.Text = temp;
        temp = spiCfg.wDelayComEnd.ToString();
        TextBox2.Text = temp;
        temp = spiCfg.wDelayFrameEnd.ToString();
        TextBox11.Text = temp;
        temp = spiCfg.wDelayDataEnd.ToString();
        TextBox10.Text = temp;
        if ((spiCfg.wSPIConfig & DATASIZE_BIT) == DATASIZE_BIT)
            CheckBox1.Checked = true;
        else
            CheckBox1.Checked = false;

        if ((spiCfg.wSPIConfig & MODE_BIT) == MODE_BIT)
            CheckBox2.Checked = false;
        else
            CheckBox2.Checked = true;

        if ((spiCfg.wSPIConfig & ORDER_BIT) == ORDER_BIT)
            CheckBox3.Checked = true;
        else
            CheckBox3.Checked = false;

        if ((spiCfg.wSPIConfig & DIR_BIT) == DIR_BIT)
            CheckBox4.Checked = true;
        else
            CheckBox4.Checked = false;

        TextBox6.Text = gpioCfg.ToString("X4");
        TextBox9.Text = gpioValue.ToString("X2");

        ComboBox3.SelectedIndex = trigCfg.byIOTrigOptions;
        ComboBox5.SelectedIndex = trigCfg.byActions;

        if (trigCfg.dwPeriod < 1000)
        {
            ComboBox4.SelectedIndex = 2;
            TextBox13.Text = trigCfg.dwPeriod.ToString();
        }
        else if (trigCfg.dwPeriod < 1000000)
        {
            ComboBox4.SelectedIndex = 1;
            TextBox13.Text = (trigCfg.dwPeriod / 1000).ToString();
        }
        else
        {
            ComboBox4.SelectedIndex = 0;
            TextBox13.Text = (trigCfg.dwPeriod / 1000000).ToString();
        }

        if ((trigCfg.byTrigCon & 0x01) == 0x01)
        {
            RadioButton1.Checked = true;
            RadioButton2.Checked = false;
        }
        else
        {
            RadioButton1.Checked = false;
            RadioButton2.Checked = true;
        }

        TextBox12.Text = trigCfg.wTrigSize.ToString();
        TextBox14.Text = trigCfg.dwMaxCnt.ToString();
        temp = "";
        for (int i = 0; i < trigCfg.byRCmdSize; i++)
        {
          temp += trigCfg.byReadCmd[i].ToString("X2");
        }
        TextBox4.Text = temp;
        TextBox5.Text = trigCfg.wReadSize.ToString();
        
        temp = "";
        for (int i = 0; i < trigCfg.byWCmdSize; i++)
        {
            temp += trigCfg.byWriteCmd[i].ToString("X2");            
        }
        TextBox7.Text = temp;
        
        if ((trigCfg.byTrigCon & 0x80) == 0x80)
        {
            Button16.Text = "Stop Trig";
        }
        else
        {
            Button16.Text = "Start Trig";
        }

        Button2.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button3.Enabled  = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button4.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button9.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button10.Enabled = (byDevIndex != 0xFF);
        Button11.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button13.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button15.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        Button16.Enabled = (byDevIndex != 0xFF && (spiCfg.wSPIConfig & 0x80) != 0x80);
        if (byDevIndex != 0xFF)
        {
            Button1.Text = "Disconnect";
            this.Text = "SPI_RW::<" + serialNo.ToString() + ">";
        }
        else
        {
            Button1.Text = "Connect";
            this.Text = "SPI_RW::Disconnect";
        }
        Label11.Text = readCnt.ToString("00000000");
        Label12.Text = writeCnt.ToString("00000000");
    }
    private bool IsHex(string str)
    {
        UInt16 length;
        UInt16 i;
        length = (UInt16)str.Length;
        if (length == 0)
            return true;
        if (length > 256 || length % 2 == 1)
            return false;
        for (i = 0; i < length; i++)
        {
            if (str[i] >= '0' && str[i] <= '9')
                continue;
            else if (str[i] >= 'a' && str[i] <= 'f')
                continue;
            else if (str[i] >= 'A' && str[i] <= 'F')
                continue;
            else
                return false;

        }
        return true;
    }

    private bool IsDigit(string str)
    {
        short length, i;
        length = (short)str.Length;
        if (length == 0)
            return false;

        for (i = 0; i < length; i++)
        {
            if ((str[i] >= '0') && (str[i] <= '9'))
                continue;
            else
                return false;
        }
        return true;
    }

    private void Val2Str(ref string str, byte[] bytes, int len, byte start)
    {
        UInt32 i;
        UInt32 j;
        j = start;
        for (i = 0; i < len; i++)
        {
            //str = str.Insert(str.Length, "\x20");
            str = str.Insert(str.Length, bytes[i].ToString("X2"));
            str = str.Insert(str.Length, "\x20");
            j = j + 3;
            if (j >= 48)
            {
                str.Insert(str.Length, "\x0D");
                str.Insert(str.Length, "\x0A");
                j = 0;
            }
        }
    }

    private void Str2Val(byte[] bytes, string str)
    {
        int length;
        int j, i;
        byte chH, chL;
        length = str.Length;
        j = 0;
        i = 0;
        while (j < length)
        {
            chH = (byte)str[j];
            if (chH == 0x20 || chH == 0x0D || chH == 0x0A)
                j = j + 1;
            else
            {
                j = j + 1;
                chL = (byte)str[j];
                bytes[i] = (byte)(CharToBcd(chH) * 16 + CharToBcd(chL));
                j = j + 1;
                i = i + 1;
            }

        }
    }

    private byte CharToBcd(byte ch)
    {
        byte mBCD = 0;
        if (ch >= 0x30 && ch <= 0x39)
            mBCD = (byte)(ch - 0x30);
        else if (ch >= 'a' && ch <= 'f')
            mBCD = (byte)(ch - 'a' + 10);
        else if (ch >= 'A' && ch <= 'F')
            mBCD = (byte)(ch - 'A' + 10);

        return mBCD;
    }

    protected override void WndProc(ref Message m)
      {

          if (m.Msg == GlobalVar.WM_USB_STATUS)
          {
              if ((byte)m.WParam == byDevIndex && (byte)m.LParam != 0x80)
              {
                  byDevIndex = 255;

                  UpdateController();
              }
          }       
       
       base.WndProc(ref m);
      }      
 
    private void Form1_Load(object sender, EventArgs e)  //form load
    {
        
        GlobalVar.mHandle = this.Handle;
        DLLImport.M3F20xm_SetUSBNotify(true, GlobalVar.USB_Event);
        byDevIndex = 0xFF;      
        serialNo = new StringBuilder(12);
        readCnt = 0;
        writeCnt = 0;
        gpioCfg = 0;
        gpioValue = 0;
        verified = 0;
        spiCfg.wSPIConfig = 0x04 + 0x20;//master, MSB,1/32 devider
        spiCfg.wDelayComEnd = 0;
        spiCfg.wDelayCSLow = 0;
        spiCfg.wDelayDataEnd = 0;
        spiCfg.wDelayFrameEnd = 0;
        trigCfg.byTrigCon = 0;
        trigCfg.byIOTrigOptions = 1;
        trigCfg.byActions = 0;
        trigCfg.dwPeriod = 10000;
        trigCfg.wTrigSize = 3072;
        trigCfg.dwMaxCnt = 0;
        trigCfg.byRCmdSize = 1;
        //trigCfg.byReadCmd[0] = 0x12;
        trigCfg.byReadCmd = new byte[16] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        trigCfg.byWriteCmd = new byte[16] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        trigCfg.byWCmdSize = 1;
        ////trigCfg.byWriteCmd[0] = 0x34;       
        trigCfg.wReadSize = 16;
        UpdateController();  
       
 
    }
 
    private void Form1_FormClosing(object sender, FormClosedEventArgs e)
    {
        if (byDevIndex != 0xFF)
            DLLImport.M3F20xm_CloseDevice(byDevIndex);

       // e.Cancel = false;
    }

    private void Button1_Click(object sender, EventArgs e)  //connect or disconnect
    {
        if (byDevIndex == 0xFF)
        {
            byDevIndex = DLLImport.M3F20xm_OpenDevice();
            if (byDevIndex == 0xFF)
            {
                MessageBox.Show("No found M3F20xm device!");
                return;
            }
            if (!DLLImport.M3F20xm_Verify(byDevIndex, ref verified))
            {
              MessageBox.Show("Fail to Call M3F20xm_Verify!");
              return;
            }
            if (verified == 1)
            {
                DLLImport.M3F20xm_GetSerialNo(byDevIndex, serialNo);
                DLLImport.M3F20xm_SPIGetConfig(byDevIndex, ref spiCfg);
               // if (DLLImport.M3F20xm_TrigGetConfig(byDevIndex, ref trigCfg))
                   // trigCfg.dwMaxCnt = (trigCfg.dwMaxCnt >> 16) + (trigCfg.dwMaxCnt << 16); //don't know why
                DLLImport.M3F20xm_TrigGetConfig(byDevIndex, ref trigCfg);
                DLLImport.M3F20xm_GPIOGetConfig(byDevIndex, ref gpioCfg);
                DLLImport.M3F20xm_GPIORead(byDevIndex, ref gpioValue);
            }
            else
            {
                MessageBox.Show("The device not authorized!");
                DLLImport.M3F20xm_CloseDevice(byDevIndex);
                byDevIndex = 0xFF;
                return;

            }
        }
        else
        {
            if ((trigCfg.byTrigCon & 0x80) == 0x80)   //trig mode
            {
                DLLImport.M3F20xm_EnableTrig(byDevIndex, 0);
                trigCfg.byTrigCon &= 0x7F;
                timer1.Stop();
                Thread.Sleep(10);
                ReadLeft();
            }
            DLLImport.M3F20xm_CloseDevice(byDevIndex);
            byDevIndex = 0xFF;
            verified = 0;
        }
        UpdateController();
    }

    private void Button2_Click(object sender, EventArgs e)  //SPI TEST
    {
     	// TODO: 在此添加控件通知处理程序代码
      byte[] ReadBuff = new byte[MAX_DIR_RW_SIZE];
      if(writeCnt == 0)
      {
       MessageBox.Show("Please input test data");
       return;
       }
       byte[] WriteBuff = new byte[writeCnt];    
       Str2Val(WriteBuff, TextBox8.Text);

       if(writeCnt > MAX_DIR_RW_SIZE)
       {
        MessageBox.Show("Test Data can't be large than 48K BYTES");
        return;
        }

       if (!DLLImport.M3F20xm_SPITransfer(byDevIndex, WriteBuff, ReadBuff, (UInt16)writeCnt, 5000))
      {
       MessageBox.Show("Fail to call M3F20xm_SPITransfer!");
       return;
      }

      string str = "";
      Val2Str(ref str, ReadBuff, writeCnt, (byte)(TextBox3.Text.Length % 50));
      TextBox3.Text = TextBox3.Text + str.ToString();
      readCnt = readCnt + writeCnt;
      Label11.Text = readCnt.ToString("00000000");
     }

    private void Button3_Click(object sender, EventArgs e)   //version get
    {
        StringBuilder DLL = new StringBuilder(50);
        StringBuilder SYS = new StringBuilder(50);
        StringBuilder MCU = new StringBuilder(50);
       
        DLLImport.M3F20xm_GetVersion(byDevIndex, 0, DLL);
        DLLImport.M3F20xm_GetVersion(byDevIndex, 1, SYS);
        DLLImport.M3F20xm_GetVersion(byDevIndex, 2, MCU);
        Form2 f = new Form2();
        f.SetData(DLL, SYS, MCU);
        f.ShowDialog();          

    }

    private void Button10_Click(object sender, EventArgs e)  //SPI cofig set
    {
       SPI_CONFIG cfg;
       cfg = spiCfg;
       cfg.wSPIConfig &= (UInt16)(0xFFFF ^ FREQUENCY_BIT);
       cfg.wSPIConfig += (UInt16)(ComboBox1.SelectedIndex << 3);
       cfg.wSPIConfig += (UInt16)ComboBox2.SelectedIndex;
       if(!CheckBox1.Checked)
           cfg.wSPIConfig &= (0xFFFF ^ DATASIZE_BIT);
      else
           cfg.wSPIConfig |= DATASIZE_BIT;

      if(!CheckBox2.Checked)
        cfg.wSPIConfig |= MODE_BIT;
      else
       cfg.wSPIConfig &= (0xFFFF ^ MODE_BIT);

      if (!CheckBox3.Checked)
          cfg.wSPIConfig &= (0xFFFF ^ ORDER_BIT);
      else
          cfg.wSPIConfig |= ORDER_BIT;

      if (!CheckBox4.Checked)
         cfg.wSPIConfig &= (0xFFFF ^ DIR_BIT);
      else
          cfg.wSPIConfig |= DIR_BIT;

      if(TextBox1.Text.Length !=0 )
        cfg.wDelayCSLow = Convert.ToUInt16(TextBox1.Text);
      if (TextBox2.Text.Length != 0)
        cfg.wDelayComEnd = Convert.ToUInt16(TextBox2.Text);
      if (TextBox11.Text.Length != 0)
        cfg.wDelayFrameEnd = Convert.ToUInt16(TextBox11.Text);
      if (TextBox10.Text.Length != 0)
        cfg.wDelayDataEnd = Convert.ToUInt16(TextBox10.Text);
      if (!DLLImport.M3F20xm_SPISetConfig(byDevIndex,ref cfg))
      {
       MessageBox.Show("Fail to call M3F20xm_SPISetConfig");
       return;
      }
      if((spiCfg.wSPIConfig & MODE_BIT) == MODE_BIT && (cfg.wSPIConfig & MODE_BIT) == 0)     //enter slaver mode
      {
        DLLImport.M3F20xm_InitFIFO(byDevIndex);
        timer1.Start();
        dwReadSize = 0;
      }
      else if ((spiCfg.wSPIConfig & MODE_BIT) == 0 && (cfg.wSPIConfig & MODE_BIT) == MODE_BIT) //exit slaver mode
      {
        timer1.Stop();
        Thread.Sleep(10);
        ReadLeft();
       }
      spiCfg = cfg;
      UpdateController();   
    }

    private void Button4_Click(object sender, EventArgs e)  //SPI read
    {
        Int32 length;
        byte[] command = new byte[256];       

        if (!IsHex(TextBox4.Text))
        {
            MessageBox.Show("Please input corrent hex string for command ");
            return;
        }
        if (!IsDigit(TextBox5.Text))
        {
            MessageBox.Show("Please input correct digit string for length");
            return;
        }
        Str2Val(command, TextBox4.Text);
       
        length = Convert.ToInt32(TextBox5.Text);
       // if (length >= MAX_DMA_RW_SIZE)
       // {
       //     MessageBox.Show("Read length must less than 65535");
      //      return;
      //  }
        if (length == 0)
        {
            MessageBox.Show("Read length must more than 0");
            return;
        }

        if ((spiCfg.wSPIConfig & DIR_BIT) == DIR_BIT)   //direct
        {

            if (length > MAX_DIR_RW_SIZE)
                length = (Int32)MAX_DIR_RW_SIZE;

        }
        else
        {

            if (length > MAX_DMA_RW_SIZE)
                length = (Int32)MAX_DMA_RW_SIZE;

        }
        byte[] readBuff = new byte[length];


        if (DLLImport.M3F20xm_SPIRead(byDevIndex, command, (byte)(TextBox4.Text.Length / 2), readBuff, (UInt16)length,5000))
        {
            string str = "";
            Val2Str(ref str, readBuff, length, (byte)(TextBox3.Text.Length % 50));
            TextBox3.Text = TextBox3.Text + str.ToString();
            readCnt = readCnt + length;
            Label11.Text = readCnt.ToString("00000000");
        }
        else
        {
            MessageBox.Show("M3F20xm_SPIRead fail");
        }
    }

    private void Button5_Click(object sender, EventArgs e)  //SPI clean read buff
    {
        readCnt = 0;
        TextBox3.Clear();
        Label11.Text = readCnt.ToString("00000000");

    }

    private void Button6_Click(object sender, EventArgs e)  //SPI save file
    {
        string sourcename;
        FileStream f;
        if (readCnt == 0)
        {
            MessageBox.Show("No data for save");
            return;
        }

        if (SaveFileDialog1.ShowDialog() == DialogResult.OK)
        {
            sourcename = SaveFileDialog1.FileName;
            f = new FileStream(sourcename, FileMode.Create);
            byte[] readBuff = new byte[readCnt];
            Str2Val(readBuff, TextBox4.Text);
            f.Write(readBuff, 0, readCnt);
            f.Close();
        }
    }

    private void Button8_Click(object sender, EventArgs e)   //SPI clear write buff
    {
        writeCnt = 0;
        TextBox8.Clear();
        Label12.Text = readCnt.ToString("00000000");

    }

    private void Button7_Click(object sender, EventArgs e)    //SPI Load file
    {
        string sourcename;
        FileStream f;
        string str = "";
        if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
        {
            sourcename = OpenFileDialog1.FileName;
            f = new FileStream(sourcename, FileMode.Open);
            writeCnt = (int)f.Length;
            byte[] WriteBuff = new byte[writeCnt];
            f.Read(WriteBuff, 0, writeCnt);
            Val2Str(ref str, WriteBuff, writeCnt, 0);
            f.Close();
            Label12.Text = writeCnt.ToString("00000000");
            TextBox8.Text = str;
        }

    }

    private void Button9_Click(object sender, EventArgs e)   //SPI write
    {
        byte[] command = new byte[256];
        
        if (!IsHex(TextBox7.Text))
        {
            MessageBox.Show("Please input corrent hex string for command ");
            return;
        }
        if (TextBox7.Text.Length == 0 && writeCnt == 0)
        {
            MessageBox.Show("Please input write data ");
            return;
        }
        if ((spiCfg.wSPIConfig & DIR_BIT) == DIR_BIT)   //direct
        {

            if (writeCnt > MAX_DIR_RW_SIZE)
            {
                MessageBox.Show("The Write length must be less than 48K!");
            }

        }
        else
        {

            if (writeCnt > MAX_DMA_RW_SIZE)
            {
                MessageBox.Show("The Write length must be less than 2M!");
                return;
            }
        }


        Str2Val(command, TextBox7.Text);
        byte[] WriteBuff = new byte[writeCnt];
        Str2Val(WriteBuff, TextBox8.Text);
        if (DLLImport.M3F20xm_SPIWrite(byDevIndex, command, (byte)(TextBox7.Text.Length / 2), WriteBuff, (UInt32)writeCnt, 5000))
        {
        }
        else
        {
            MessageBox.Show("M3F20xm_SPIWrite fail");
        }
    }  

    private void button11_Click(object sender, EventArgs e)  //GPIO config set
    {
     string str = TextBox6.Text;
   
     if (!IsHex(str) || str.Length == 0)
     {
         MessageBox.Show("Please input corrent hex string for GPIO config ");
         return;
     }

     int dir = (CharToBcd((byte)str[3]) << 12) + (CharToBcd((byte)str[2]) << 8) + (CharToBcd((byte)str[1]) << 4) + CharToBcd((byte)str[0]);
     if (DLLImport.M3F20xm_GPIOSetConfig(byDevIndex, (UInt16)dir))
     {
         MessageBox.Show("GPIO config ok");
         DLLImport.M3F20xm_GPIORead(byDevIndex, ref gpioValue);
         gpioCfg = (UInt16)dir;
         UpdateController();
     }
    }   

    private void button13_Click(object sender, EventArgs e)
    {
        string str = TextBox9.Text;
       
        if (!IsHex(str) || str.Length == 0)
        {
            MessageBox.Show("Please input corrent hex string for GPIO value ");
            return;
        }

        byte v = (byte)(CharToBcd((byte)str[1]) * 16 + CharToBcd((byte)str[0]));
        if (DLLImport.M3F20xm_GPIOWrite(byDevIndex, v,0xff) == false)
        {
            MessageBox.Show("M3F20xm_GPIOWrite fail");
            return;
        }
        DLLImport.M3F20xm_GPIORead(byDevIndex, ref gpioValue);
        UpdateController();
    }

    private void Button15_Click(object sender, EventArgs e)
    {
        TRIG_CONFIG tempCfg;
        UInt32 trigSize;
        UInt32 period,maxcnt;
        string str;
        tempCfg = trigCfg;
        if (RadioButton1.Checked)
            tempCfg.byTrigCon |= 0x01;
        else
            tempCfg.byTrigCon &= 0xFE;
        tempCfg.byIOTrigOptions = (byte)ComboBox3.SelectedIndex;
        tempCfg.byActions = (byte)ComboBox5.SelectedIndex;
        str = TextBox13.Text;
        if (str.Length == 0)
        {
            MessageBox.Show("Please input timer internal");
            return;
        }
        period = Convert.ToUInt32(str);
        if (ComboBox4.SelectedIndex == 0)
        {
            tempCfg.dwPeriod = period * 1000000;
        }
        else if (ComboBox4.SelectedIndex == 1)
        {
            tempCfg.dwPeriod = period * 1000;
        }
        else
        {
            tempCfg.dwPeriod = period;
        }
        if (tempCfg.dwPeriod == 0)
        {
            MessageBox.Show("The internal can't be equal to 0");
            return;
        }
        if (tempCfg.dwPeriod > 30000000)
        {
            MessageBox.Show("The internal can't be large than 30s");
            return;
        }

        str = TextBox12.Text;
        if (str.Length == 0)
        {
            MessageBox.Show("Please input trig size");
            return;
        }
        trigSize = Convert.ToUInt32(str);
        if (trigSize > 3072)
        {
            MessageBox.Show("The Trig size can't be large than 3072!");
            return;
        }
        tempCfg.wTrigSize = (UInt16)trigSize;

        str = TextBox14.Text;
        if (str.Length == 0)
        {
            MessageBox.Show("Please input trig counter");
            return;
        }
        tempCfg.dwMaxCnt = Convert.ToUInt32(str);
        //maxcnt = Convert.ToUInt32(str);
        //trigCfg.dwMaxCnt = (maxcnt >> 16) + (maxcnt << 16); //don't know why
        str = TextBox4.Text;
        if (IsHex(str) == false || str.Length == 0)
        {
            MessageBox.Show("Incorrect format for read command!");
            return;
        }
        tempCfg.byRCmdSize = (byte)(str.Length / 2);
        Str2Val(tempCfg.byReadCmd, str);

        str = TextBox5.Text;
        if (str.Length == 0)
        {
            MessageBox.Show("Please input read length!");
            return;
        }
        tempCfg.wReadSize = Convert.ToUInt16(str);
        if (tempCfg.wReadSize == 0)
        {
            MessageBox.Show("Read length can't be equal to 0");
            return;
        }

        str = TextBox7.Text;
        if (IsHex(str) == false || str.Length == 0)
        {
            MessageBox.Show("Incorrect format for write command!");
            return;
        }
        tempCfg.byWCmdSize = (byte)(str.Length / 2);
        Str2Val(tempCfg.byWriteCmd, str);

        if (!DLLImport.M3F20xm_TrigSetConfig(byDevIndex, ref tempCfg))
        {
            MessageBox.Show("Fail to call M3F20xm_TrigSetConfig");
            return;
        }
        trigCfg = tempCfg;
    
    }

    private void Button16_Click(object sender, EventArgs e)
    {
       if ((trigCfg.byTrigCon & 0x80) == 0x80)  // is running
        {
            if (DLLImport.M3F20xm_EnableTrig(byDevIndex,0))
            {
                trigCfg.byTrigCon = (byte)(trigCfg.byTrigCon & 0x7F);
                timer1.Stop();
                Thread.Sleep(10);
                ReadLeft();
            }
        }
        else
        {
            if (DLLImport.M3F20xm_EnableTrig(byDevIndex,1))
            {
                trigCfg.byTrigCon = (byte)(trigCfg.byTrigCon | 0x80);
                timer1.Start();
                DLLImport.M3F20xm_InitFIFO(byDevIndex);
                dwReadSize = 0;
            }
        }
        UpdateController();
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
       byte[] buff = new byte[USB_POLL_SIZE];
       UInt32 realSize = 0;
      if (DLLImport.M3F20xm_ReadFIFO(byDevIndex, buff, USB_POLL_SIZE, ref realSize))
      {
       if(realSize > 0)
       {
           string str = "";
           Val2Str(ref str, buff, (int)realSize, (byte)(TextBox3.Text.Length % 50));
           TextBox3.Text = TextBox3.Text + str.ToString();
           readCnt = readCnt + (int)realSize;
           Label11.Text = readCnt.ToString("00000000");
           dwReadSize += realSize;

      }
  }
  if((trigCfg.byTrigCon & 0x80) == 0x80)     //trig mode
  {
   if (trigCfg.dwMaxCnt >0  && trigCfg.dwMaxCnt == (UInt32)(dwReadSize / trigCfg.wReadSize))
   {
     trigCfg.byTrigCon &= 0x7F;
     UpdateController();
     timer1.Stop();
    return;
   }
  }
    }

    private void ReadLeft()    
    {
        UInt32  leftSize;
        leftSize = 0;
        if(DLLImport.M3F20xm_GetFIFOLeft(byDevIndex,ref leftSize))
        {
            if (leftSize == 0)
            {
                MessageBox.Show("There is no left byte!");
                return;
            }
           byte[] pBuf = new byte[leftSize];
           if(DLLImport.M3F20xm_ReadFIFO(byDevIndex,pBuf,leftSize,ref leftSize))
           {
               string str = "";
               Val2Str(ref str, pBuf, (int)leftSize, (byte)(TextBox3.Text.Length % 50));
               TextBox3.Text = TextBox3.Text + str.ToString();
               readCnt = readCnt + (int)leftSize;
               Label11.Text = readCnt.ToString("00000000");
            }
  
          }
         else
           MessageBox.Show("Fail to call M3F20xm_GetLeftSize");
    }

   
    }
}
