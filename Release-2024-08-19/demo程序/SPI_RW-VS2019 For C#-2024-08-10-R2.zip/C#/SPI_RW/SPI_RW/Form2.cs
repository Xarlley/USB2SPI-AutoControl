﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SPI_RW
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public void SetData(StringBuilder str1, StringBuilder str2, StringBuilder str3)
        {
            Label5.Text = str1.ToString();
            Label6.Text = str2.ToString();
            Label7.Text = str3.ToString();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

    }
}
