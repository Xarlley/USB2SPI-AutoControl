Declare Function USBIO_OpenDevice Lib "usb2uis.dll" () As Byte

Declare Function USBIO_CloseDevice Lib "usb2uis.dll" (ByVal bComId As Byte) As Boolean

