﻿Module userdefine
    Public WM_USB_STATUS = &H400 + 100
    Public mHandle As Integer
    Public sFormTitle As String
    Public Declare Function PostMessage Lib "user32" Alias "PostMessageA" (ByVal hwnd As Int32, ByVal wMsg As Int32, ByVal wParam As Int32, ByVal lParam As Int32) As Long
    Private Declare Auto Function FindWindow Lib "user32" (ByVal lpClassName As String, ByVal lpWindowName As String) As Integer
    Public Delegate Function CallBack(ByVal byIndex As Byte, ByVal dwStatus As UInteger) As Boolean

    Public Function USB_Event(ByVal byIndex As Byte, ByVal dwUSBStatus As UInteger) As Boolean
        mHandle = FindWindow(vbNullString, sFormTitle)
        PostMessage(mHandle, WM_USB_STATUS, byIndex, dwUSBStatus)
        Return True
    End Function
End Module


Public Structure SPI_CONFIG

    ' wSPIConfig:  
    '  bit15  for SPI R/W access mode         1- Directed    , 0- DMA
    '  bit12  for SPI Frame length:             1- 16 bit      , 0- 8 bit
    '  bit7   for SPI Frame format:             1- LSB first   , 0- MSB first
    '  bit5~3 for SPI frequency devide factor:  SPI frequecy = SYSCLK / ( factor + 1)
    '  bit2   for SPI mode:                     1- Master      , 0- Slaver
    '  bit1   for SPI CLK level when idle:      1- High        , 0- Low
    '  bit0   for SPI CLK capture:              1- the Second edge,0- the First edge                   

    Dim wSPIConfig As UInt16
    ' the delay time after CS becomes low, unit us  
    Dim wDelayCSLow As UInt16
    'the delay time after sends command, unit us
    Dim wDelayComEnd As UInt16
    'the delay time after sends or receives a frame
    Dim wDelayFrameEnd As UInt16
    'the delay time after sends oe receives all the data
    Dim wDelayDataEnd As UInt16
    Dim wReserved As UInt16
End Structure

Public Structure TRIG_CONFIG
    '	  byTrigCon:
    ' 	    bit7   for Trig staus:                  1- Trig opened,  0- Trig closed
    '	    bit0   got Trig type:                   1- IO Trig,      0- Timer Trig 	       

    Dim byTrigCon As Byte

    '	  byIOTrigOptions:  for IO Trig type
    '	     0-- raising edge
    '	     1-- falling edge
    '	     2-- raising or falling edge

    Dim byIOTrigOptions As Byte

    Dim byUnused As Byte

    '	 byActions: the action after trigged
    '	 0: Execute Read
    '	 1: Execute write and read
    '	 2: Execute read and write

    Dim byActions As Byte
    '   dwPeriod: Timer trig period, unit us 
    Dim dwPeriod As UInt32
    ' byRCmdSize: read commamd size, in bytes 
    Dim byRCmdSize As Byte
    ' byWCmdSize: write commamd size, in bytes 
    Dim byWCmdSize As Byte
    ' byReadCmd: read commad buff
    Dim byReadCmd() As Byte
    ' byWriteCmd: write commad buff
    Dim byWriteCmd() As Byte
    ' wReadSize: read data size, must be less than 3072 
    Public wReadSize As UInt16
    ' wTrigSize: trig buff size, must be less than 3072
    '  it will send data to upport while read data is equal to wTrigSize

    Public wTrigSize As UInt16
    Public wReserved As UInt16
    'dwTrigCnt: current trig counter
    Public dwTrigCnt As UInt32
    ' dwMaxCnt: Max Enabled trig number , trig will exit if dwTrigCnt is equal to dwMaxCnt 
    Public dwMaxCnt As UInt32
End Structure

Module ExtenalDll

#If X64 Then
    Public Declare Function M3F20xm_SetUSBNotify Lib "M3F20xm.dll" (ByVal bLoged As Boolean, ByVal pUSB_CallBack As CallBack) As Boolean

    Public Declare Function M3F20xm_OpenDevice Lib "M3F20xm.dll" () As Byte
    Public Declare Function M3F20xm_OpenDeviceByNumber Lib "M3F20xm.dll" (ByVal pSerialString() As String) As Byte
    Public Declare Function M3F20xm_CloseDevice Lib "M3F20xm.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_CloseDeviceByNumber Lib "M3F20xm.dll" (ByVal pSerialString As String) As Boolean
    Public Declare Function M3F20xm_ResetDevice Lib "M3F20xm.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_Verify Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef lpResult As Boolean) As Boolean

    Public Declare Function M3F20xm_GetVersion Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal byType As Byte, ByVal lpBuffer As String) As Boolean
    Public Declare Function M3F20xm_GetSerialNo Lib "M3F20xm.dll"(ByVal byIndex As Byte, ByVal lpBuff As String) As Boolean
    Public Declare Function M3F20xm_GetDFUMode Lib "M3F20xm.dll" (ByVal byIndex As Byte) As Boolean


    Public Declare Function M3F20xm_SPIGetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef pCfg As SPI_CONFIG) As Boolean
    Public Declare Function M3F20xm_SPISetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef pCfg As SPI_CONFIG) As Boolean
    Public Declare Function M3F20xm_SPIRead Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal byCmd() As Byte, ByVal byComSize As Byte, ByVal byReadData() As Byte, ByVal dwReadSize As UInt32, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_SPIWrite Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal byCmd() As Byte, ByVal byComSize As Byte, ByVal byWriteData() As Byte, ByVal dwWriteSize As Short, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_SPITransfer Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal lpWriteBuffer() As Byte, ByVal lpReadBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean



    Public Declare Function M3F20xm_GPIOGetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef pdwValue As UInt32) As Boolean
    Public Declare Function M3F20xm_GPIOSetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal dwValue As UInt32) As Boolean
    Public Declare Function M3F20xm_GPIORead Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef pbyValue As Byte) As Byte
    Public Declare Function M3F20xm_GPIOWrite Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal byValue As Byte, ByVal byMask As Byte) As Boolean


    Public Declare Function M3F20xm_EnableTrig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal bOn As Boolean) As Boolean
    Public Declare Function M3F20xm_TrigGetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte) As Boolean
    Public Declare Function M3F20xm_TrigSetConfig Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte) As Boolean


    Public Declare Function M3F20xm_BuffRead Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal wAddr As UInt16, ByVal bylpBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_BuffWrite Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal wAddr As UInt16, ByVal bylpBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean
  
    Public Declare Function M3F20xm_InitFIFO Lib "M3F20xm.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ReadFIFO Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte, ByVal dwBuffSize As UInt32, ByRef pdwRealSize As UInt32) As Boolean
    Public Declare Function M3F20xm_GetFIFOLeft Lib "M3F20xm.dll" (ByVal byIndex As Byte, ByRef pdwBuffsize As UInt32) As Boolean
#Else
    Public Declare Function M3F20xm_SetUSBNotify Lib "M3F20xm.dll" Alias "_M3F20xm_SetUSBNotify@8" (ByVal bLoged As Boolean, ByVal pUSB_CallBack As CallBack) As Boolean

    Public Declare Function M3F20xm_OpenDevice Lib "M3F20xm.dll" Alias "_M3F20xm_OpenDevice@0" () As Byte
    Public Declare Function M3F20xm_OpenDeviceByNumber Lib "M3F20xm.dll" Alias "_M3F20xm_OpenDeviceByNumber@4" (ByVal pSerialString() As String) As Byte
    Public Declare Function M3F20xm_CloseDevice Lib "M3F20xm.dll" Alias "_M3F20xm_CloseDevice@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_CloseDeviceByNumber Lib "M3F20xm.dll" Alias "_M3F20xm_CloseDeviceByNumber@4" (ByVal pSerialString As String) As Boolean
    Public Declare Function M3F20xm_ResetDevice Lib "M3F20xm.dll" Alias "_M3F20xm_ResetDevice@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_Verify Lib "M3F20xm.dll" Alias "_M3F20xm_Verify@8" (ByVal byIndex As Byte, ByRef lpResult As Boolean) As Boolean

    Public Declare Function M3F20xm_GetVersion Lib "M3F20xm.dll" Alias "_M3F20xm_GetVersion@12" (ByVal byIndex As Byte, ByVal byType As Byte, ByVal lpBuffer As String) As Boolean
    Public Declare Function M3F20xm_GetSerialNo Lib "M3F20xm.dll" Alias "_M3F20xm_GetSerialNo@8" (ByVal byIndex As Byte, ByVal lpBuff As String) As Boolean
    Public Declare Function M3F20xm_GetDFUMode Lib "M3F20xm.dll" Alias "_M3F20xm_DFUMode@4" (ByVal byIndex As Byte) As Boolean


    Public Declare Function M3F20xm_SPIGetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_SPIGetConfig@8" (ByVal byIndex As Byte, ByRef pCfg As SPI_CONFIG) As Boolean
    Public Declare Function M3F20xm_SPISetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_SPISetConfig@8" (ByVal byIndex As Byte, ByRef pCfg As SPI_CONFIG) As Boolean
    Public Declare Function M3F20xm_SPIRead Lib "M3F20xm.dll" Alias "_M3F20xm_SPIRead@24" (ByVal byIndex As Byte, ByVal byCmd() As Byte, ByVal byComSize As Byte, ByVal byReadData() As Byte, ByVal dwReadSize As UInt32, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_SPIWrite Lib "M3F20xm.dll" Alias "_M3F20xm_SPIWrite@24" (ByVal byIndex As Byte, ByVal byCmd() As Byte, ByVal byComSize As Byte, ByVal byWriteData() As Byte, ByVal dwWriteSize As Short, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_SPITransfer Lib "M3F20xm.dll" Alias "_M3F20xm_SPITransfer@20" (ByVal byIndex As Byte, ByVal lpWriteBuffer() As Byte, ByVal lpReadBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean



    Public Declare Function M3F20xm_GPIOGetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_GPIOGetConfig@8" (ByVal byIndex As Byte, ByRef pdwValue As UInt32) As Boolean
    Public Declare Function M3F20xm_GPIOSetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_GPIOSetConfig@8" (ByVal byIndex As Byte, ByVal dwValue As UInt32) As Boolean
    Public Declare Function M3F20xm_GPIORead Lib "M3F20xm.dll" Alias "_M3F20xm_GPIORead@8" (ByVal byIndex As Byte, ByRef pbyValue As Byte) As Byte
    Public Declare Function M3F20xm_GPIOWrite Lib "M3F20xm.dll" Alias "_M3F20xm_GPIOWrite@12" (ByVal byIndex As Byte, ByVal byValue As Byte, ByVal byMask As Byte) As Boolean


    Public Declare Function M3F20xm_EnableTrig Lib "M3F20xm.dll" Alias "_M3F20xm_EnableTrig@8" (ByVal byIndex As Byte, ByVal bOn As Boolean) As Boolean
    Public Declare Function M3F20xm_TrigGetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_TrigGetConfig@8" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte) As Boolean
    Public Declare Function M3F20xm_TrigSetConfig Lib "M3F20xm.dll" Alias "_M3F20xm_TrigSetConfig@8" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte) As Boolean


    Public Declare Function M3F20xm_BuffRead Lib "M3F20xm.dll" Alias "_M3F20xm_BuffRead@20" (ByVal byIndex As Byte, ByVal wAddr As UInt16, ByVal bylpBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean
    Public Declare Function M3F20xm_BuffWrite Lib "M3F20xm.dll" Alias "_M3F20xm_BuffWriteg@20" (ByVal byIndex As Byte, ByVal wAddr As UInt16, ByVal bylpBuffer() As Byte, ByVal wBuffSize As UInt16, ByVal dwTimeout As UInt32) As Boolean
  
    Public Declare Function M3F20xm_InitFIFO Lib "M3F20xm.dll" Alias "_M3F20xm_InitFIFO@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ReadFIFO Lib "M3F20xm.dll" Alias "_M3F20xm_ReadFIFO@16" (ByVal byIndex As Byte, ByVal bylpBuffer() As Byte, ByVal dwBuffSize As UInt32, ByRef pdwRealSize As UInt32) As Boolean
    Public Declare Function M3F20xm_GetFIFOLeft Lib "M3F20xm.dll" Alias "_M3F20xm_GetFIFOLeft@8" (ByVal byIndex As Byte, ByRef pdwBuffsize As UInt32) As Boolean

#End If






End Module
