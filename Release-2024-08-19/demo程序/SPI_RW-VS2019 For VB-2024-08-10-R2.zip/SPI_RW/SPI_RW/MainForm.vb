﻿Imports System.Threading

'Imports System
'Imports System.Runtime.InteropServices




Public Class MainForm
    Public INFINITE = &HFFFFFFFFUI
    Public DIR_BIT = &H8000
    Public DATASIZE_BIT = &H800
    Public ORDER_BIT = &H80
    Public FREQUENCY_BIT = &H38
    Public MODE_BIT = &H4
    Public CPOL_BIT = &H2
    Public CPHA_BIT = &H1
    Public MAX_DMA_RW_SIZE = (2 * 1024 * 1024)
    Public MAX_DIR_RW_SIZE = (48 * 1024)
    Public USB2SPI_BUFFSIZE = 3072
    Public USB_POLL_SIZE = (64 * 1024)


    Dim byDeviceId As Byte
    Dim serialNo As String
    Dim spiCfg As SPI_CONFIG
    Dim trigCfg As TRIG_CONFIG
    Dim gpioCfg As UInt32
    Dim gpioValue As UInt32
    Dim readCnt, WriteCnt, dwReadSize As UInt32

   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ((trigCfg.byTrigCon And &H80) = &H80) Then
            If (M3F20xm_EnableTrig(byDeviceId, False)) Then
                trigCfg.byTrigCon = (trigCfg.byTrigCon And &H7F)
                Timer1.Stop()
                Thread.Sleep(10)
                ReadLeft()
            End If
        Else
            If (M3F20xm_EnableTrig(byDeviceId, True)) Then
                trigCfg.byTrigCon = (trigCfg.byTrigCon Or &H80)
                Timer1.Start()
                M3F20xm_InitFIFO(byDeviceId)
                dwReadSize = 0
            End If
        End If
        InitControl()
    End Sub

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        byDeviceId = 255
        serialNo = "??????????"
        'master, MSB,1/32 devider
        ReDim trigCfg.byWriteCmd(16)
        ReDim trigCfg.byReadCmd(16)
        spiCfg.wSPIConfig = &H4 + &H20
        spiCfg.wDelayComEnd = 0
        spiCfg.wDelayCSLow = 0
        spiCfg.wDelayDataEnd = 0
        spiCfg.wDelayFrameEnd = 0
        trigCfg.byTrigCon = 0
        trigCfg.byIOTrigOptions = 1
        trigCfg.byActions = 0
        trigCfg.dwPeriod = 10000
        trigCfg.wTrigSize = 3072
        trigCfg.dwMaxCnt = 0
        trigCfg.byRCmdSize = 1
        trigCfg.byReadCmd = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        trigCfg.byWriteCmd = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        trigCfg.byWCmdSize = 1
        trigCfg.wReadSize = 16
        readCnt = 0
        WriteCnt = 0
        gpioCfg = 0
        gpioValue = 0
        InitControl()
        M3F20xm_SetUSBNotify(True, AddressOf USB_Event)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim result As Boolean
        Dim dat() As Byte
        ReDim trigCfg.byWriteCmd(16)
        ReDim trigCfg.byReadCmd(16)
        ReDim dat(64)
        If (byDeviceId = 255) Then
            byDeviceId = M3F20xm_OpenDevice()
            If (byDeviceId = 255) Then
                MsgBox("No found USB2SPI device!")
            Else
                If (M3F20xm_Verify(byDeviceId, result) = True) Then
                    M3F20xm_GetSerialNo(byDeviceId, serialNo)
                    M3F20xm_SPIGetConfig(byDeviceId, spiCfg)
                    'M3F20xm_TrigGetConfig(byDeviceId, trigCfg)
                    M3F20xm_TrigGetConfig(byDeviceId, dat)
                    DataArrayToTrigConfig(dat)
                    M3F20xm_GPIOGetConfig(byDeviceId, gpioCfg)
                    M3F20xm_GPIORead(byDeviceId, gpioValue)
                Else
                    byDeviceId = 255
                    CloseDevice()
                End If
            End If
        Else
                CloseDevice()
        End If
        InitControl()
    End Sub

    Public Sub InitControl()
        Dim temp As String
        Dim i As UInt16
        ReDim trigCfg.byWriteCmd(16)
        ReDim trigCfg.byReadCmd(16)

        Label11.Text = readCnt.ToString("00000000")
        Label12.Text = WriteCnt.ToString("00000000")
        If (byDeviceId = 255) Then
            Button1.Text = "Connect"
            sFormTitle = "SPI_RW::" + "???"
            Me.Text = sFormTitle
        Else
            Button1.Text = "Disconnect"
            sFormTitle = "SPI_RW::" + serialNo
            Me.Text = sFormTitle
        End If
        ComboBox1.SelectedIndex = (spiCfg.wSPIConfig >> 3) And &H7
        ComboBox2.SelectedIndex = spiCfg.wSPIConfig And &H3
        TextBox1.Text = spiCfg.wDelayCSLow.ToString()
        TextBox2.Text = spiCfg.wDelayComEnd.ToString()
        TextBox10.Text = spiCfg.wDelayDataEnd.ToString()
        TextBox11.Text = spiCfg.wDelayFrameEnd.ToString()
        If (spiCfg.wSPIConfig And DATASIZE_BIT) Then
            CheckBox1.Checked = True
        Else
            CheckBox1.Checked = False
        End If
        If (spiCfg.wSPIConfig And MODE_BIT) Then
            CheckBox2.Checked = False
        Else
            CheckBox2.Checked = True
        End If
        If (spiCfg.wSPIConfig And ORDER_BIT) Then
            CheckBox3.Checked = True
        Else
            CheckBox3.Checked = False
        End If
        If (spiCfg.wSPIConfig And DIR_BIT) Then
            CheckBox4.Checked = True
        Else
            CheckBox4.Checked = False
        End If

        TextBox6.Text = gpioCfg.ToString("X4")
        TextBox9.Text = gpioValue.ToString("X2")

        If (trigCfg.byTrigCon And &H1 = True) Then
            RadioButton1.Checked = True
        Else
            RadioButton2.Checked = True
        End If

        ComboBox3.SelectedIndex = trigCfg.byIOTrigOptions
        ComboBox5.SelectedIndex = trigCfg.byActions

        If (trigCfg.dwPeriod < 1000) Then
            ComboBox4.SelectedIndex = 2
            TextBox13.Text = trigCfg.dwPeriod.ToString()
        ElseIf (trigCfg.dwPeriod < 1000000) Then
            ComboBox4.SelectedIndex = 1
            TextBox13.Text = (trigCfg.dwPeriod / 1000).ToString()
        Else
            ComboBox4.SelectedIndex = 0
            TextBox13.Text = (trigCfg.dwPeriod / 1000000).ToString()
        End If
        TextBox12.Text = trigCfg.wTrigSize.ToString()

        TextBox14.Text = trigCfg.dwMaxCnt.ToString()
        temp = ""
        For i = 1 To trigCfg.byRCmdSize
            temp = trigCfg.byReadCmd(i).ToString("X2")
            TextBox4.Text = temp
        Next
        TextBox5.Text = trigCfg.wReadSize.ToString()

        temp = ""
        For i = 1 To trigCfg.byWCmdSize
            temp = temp + trigCfg.byWriteCmd(i).ToString("X2")
        Next
        TextBox7.Text = temp

        If ((trigCfg.byTrigCon And &H80) = &H80) Then
            Button2.Text = "Stop Trigger"
        Else
            Button2.Text = "Start Trigger"
        End If
    End Sub
    Private Function IsHex(ByVal str As String) As Boolean
        Dim length As Short
        Dim i As Short
        length = str.Length()
        If (length = 0) Then
            Return True
        End If
        If (length Mod 2 Or length > 256) Then
            Return False
        End If
        For i = 0 To length - 1
            If ((str(i) >= "0") And (str(i) <= "9")) Then
                Continue For
            ElseIf ((str(i) >= "a") And (str(i) <= "f")) Then
                Continue For
            ElseIf ((str(i) >= "A") And (str(i) <= "F")) Then
                Continue For
            Else
                Return False
            End If
        Next i
        Return True
    End Function
    Private Function IsDigit(ByVal str As String) As Boolean
        Dim length As Short
        Dim i As Short
        length = str.Length()
        If (length = 0) Then
            Return False
        End If
        For i = 0 To length - 1
            If ((str(i) >= "0") And (str(i) <= "9")) Then
                Continue For
            Else
                Return False
            End If
        Next i
        Return True
    End Function
    Private Function BcdToChar(ByVal iBcd As Byte) As Char
        Dim hexVar As String = "0123456789ABCDEF"
        Return hexVar(iBcd)
    End Function
    Private Function CharToBcd(ByVal ch As Char) As Byte
        Dim mBCD As Byte
        If ch >= "0" And ch <= "9" Then
            mBCD = AscW(ch) - AscW("0")
        ElseIf ch >= "a" And ch <= "f" Then
            mBCD = AscW(ch) - AscW("a") + 10
        ElseIf ch >= "A" And ch <= "F" Then
            mBCD = AscW(ch) - AscW("A") + 10
        End If
        Return (mBCD)
    End Function
    Private Sub Str2Val(ByRef bytes() As Byte, ByVal str As String)
        Dim length As UInteger
        Dim j, i As UInteger
        Dim chH, chL As Char
        length = str.Length()
        j = 0
        i = 0
        While (j < length)
            chH = str(j)
            If (chH = Chr(32) Or chH = Chr(13) Or chH = Chr(10)) Then
                j = j + 1
            Else
                j = j + 1
                chL = str(j)
                bytes(i) = (CharToBcd(chH) * 16 + CharToBcd(chL))
                j = j + 1
                i = i + 1
            End If

        End While

    End Sub
    Private Sub Val2Str(ByRef str As String, ByVal bytes() As Byte, ByVal len As UInteger, ByVal start As Byte)
        Dim i As UInteger
        Dim j As Byte
        j = start
        For i = 0 To len - 1
            str = str.Insert(str.Length, Chr(32))
            str = str.Insert(str.Length, bytes(i).ToString("X2"))
            j = j + 3
            If (j >= 48) Then
                str = str.Insert(str.Length, Chr(13))
                str = str.Insert(str.Length, Chr(10))
                j = 0
            End If
        Next

    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim length As UInteger
        Dim command(256) As Byte
        Dim readBuff(1024) As Byte
        Dim str As String
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        If (spiCfg.wSPIConfig And &H4 = 0) Then
            MsgBox("SPI work as slaver")
            Return
        End If
        If (IsHex(TextBox4.Text) = False) Then
            MsgBox("Please input corrent hex string for command ")
            Return
        End If
        If (IsDigit(TextBox5.Text) = False) Then
            MsgBox("Please input correct digit string for length")
            Return
        End If
        length = Convert.ToInt32(TextBox5.Text)
        If (length = 0) Then
            MsgBox("Read length must more than 0")
            Return
        End If
        If ((spiCfg.wSPIConfig & DIR_BIT) = DIR_BIT) Then
      
            If (length > MAX_DIR_RW_SIZE) Then
                length = MAX_DIR_RW_SIZE
            End If
        Else
            If (length > MAX_DMA_RW_SIZE) Then
                length = MAX_DMA_RW_SIZE
            End If
        End If
        Str2Val(command, TextBox4.Text)
        ReDim readBuff(length)
        str = ""

        If (M3F20xm_SPIRead(byDeviceId, command, TextBox4.Text.Length / 2, readBuff, length, 5000)) Then
            Val2Str(str, readBuff, length, TextBox3.Text.Length Mod 50)
            TextBox3.Text = TextBox3.Text + str
            readCnt = readCnt + length
        Else
            MsgBox("Fail to call M3F20xm_SPIRead")
        End If
    End Sub


    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox3.Clear()
        readCnt = 0
        InitControl()


    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox8.Clear()
        WriteCnt = 0
        InitControl()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim sourcename As String
        Dim f As System.IO.FileStream
        Dim readBuff(1024) As Byte
        If readCnt = 0 Then
            MsgBox("No data for save")
            Return
        End If
        If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            sourcename = SaveFileDialog1.FileName
            f = IO.File.Open(sourcename, IO.FileMode.Create, IO.FileAccess.Write)
            ReDim readBuff(readCnt)
            Str2Val(readBuff, TextBox4.Text)
            f.Write(readBuff, 0, readCnt)
            f.Close()
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim sourcename As String
        Dim f As System.IO.FileStream
        Dim length As UInteger
        Dim WriteBuff(1024) As Byte
        Dim str As String
        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            sourcename = OpenFileDialog1.FileName
            f = IO.File.Open(sourcename, IO.FileMode.Open, IO.FileAccess.Read)
            length = f.Length
            ReDim WriteBuff(length)
            str = ""
            f.Read(WriteBuff, 0, length)
            Val2Str(str, WriteBuff, length, 0)

            TextBox8.Text = str
            WriteCnt = length
            InitControl()
            f.Close()
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Dim command(256) As Byte
        Dim WriteBuff(1024) As Byte
        If (byDeviceId = 255) Then    'disconnected
            MsgBox("Please connect the device")
            Return
        End If
        If (spiCfg.wSPIConfig And &H4 = 0) Then    'slaver mode
            MsgBox("SPI work as slaver")
            Return
        End If
        If (IsHex(TextBox7.Text) = False) Then
            MsgBox("Please input corrent hex string for command ")
            Return
        End If
        If (TextBox7.Text.Length = 0 And WriteCnt = 0) Then
            MsgBox("Please input write data ")
            Return
        End If

        If ((spiCfg.wSPIConfig And DIR_BIT) = DIR_BIT) Then
            If (WriteCnt > MAX_DIR_RW_SIZE) Then
                MessageBox.Show("The Write length must be less than 48K!")
                Return
            End If
        Else
            If (WriteCnt > MAX_DMA_RW_SIZE) Then
                MessageBox.Show("The Write length must be less than 2M!")
                Return
            End If
        End If
        Str2Val(command, TextBox7.Text)
        ReDim WriteBuff(WriteCnt)
        Str2Val(WriteBuff, TextBox8.Text)
        If (M3F20xm_SPIWrite(byDeviceId, command, TextBox7.Text.Length / 2, WriteBuff, WriteCnt, 5000)) Then
            'MsgBox("Write length must less than 65535")
        Else
            MsgBox("Fail to call M3F20xm_SPIWrite")
        End If
    End Sub

    Private Sub MainForm_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        CloseDevice()
    End Sub
    Private Sub CloseDevice()
        If (byDeviceId <> 255) Then
            If (spiCfg.wSPIConfig And &H4 = 0) Then  'at slave mode ,first exit
                spiCfg.wSPIConfig = spiCfg.wSPIConfig And &HFB
                M3F20xm_SPISetConfig(byDeviceId, spiCfg)
            End If
            'runThread.Abort()
            M3F20xm_CloseDevice(byDeviceId)
            byDeviceId = 255
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim dllVersion, sysVersion, MCUVersion, DFUVersion As String
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        dllVersion = "aaa                                                                   "
        sysVersion = "bbb                                                                   "
        MCUVersion = "ccc                                                                   "
        DFUVersion = "ddd                                                                   "
        M3F20xm_GetVersion(byDeviceId, 0, dllVersion)
        M3F20xm_GetVersion(byDeviceId, 1, sysVersion)
        M3F20xm_GetVersion(byDeviceId, 2, MCUVersion)
        M3F20xm_GetVersion(byDeviceId, 3, DFUVersion)
        Form1.SetData(dllVersion, sysVersion, MCUVersion, DFUVersion)

        Form1.ShowDialog()

    End Sub
    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        If m.Msg = WM_USB_STATUS Then
            If (m.WParam = byDeviceId And m.LParam <> &H80) Then
                M3F20xm_CloseDevice(byDeviceId)
                byDeviceId = 255
                InitControl()
            End If
        End If
        MyBase.WndProc(m)
    End Sub
    Public Function USB_Removed(ByVal byIndex As Byte, ByVal dwUSBStatus As UInteger) As Boolean
        If (byIndex = byDeviceId And dwUSBStatus <> &H80) Then
            M3F20xm_CloseDevice(byDeviceId)
            byDeviceId = 255
            InitControl()
        End If
        Return True
    End Function


    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Dim tmp As SPI_CONFIG
        tmp.wSPIConfig = 0
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        If (CheckBox1.Checked) Then
            tmp.wSPIConfig = tmp.wSPIConfig + DATASIZE_BIT
        End If
        If (CheckBox2.Checked = False) Then
            tmp.wSPIConfig = tmp.wSPIConfig + MODE_BIT
        End If
        If (CheckBox3.Checked) Then
            tmp.wSPIConfig = tmp.wSPIConfig + ORDER_BIT
        End If
        If (CheckBox4.Checked) Then
            tmp.wSPIConfig = tmp.wSPIConfig + DIR_BIT
        End If
        tmp.wDelayCSLow = Convert.ToInt32(TextBox1.Text)
        tmp.wDelayComEnd = Convert.ToInt32(TextBox2.Text)
        tmp.wDelayDataEnd = Convert.ToInt32(TextBox10.Text)
        tmp.wDelayFrameEnd = Convert.ToInt32(TextBox11.Text)
        tmp.wSPIConfig = tmp.wSPIConfig + ComboBox2.SelectedIndex
        tmp.wSPIConfig = tmp.wSPIConfig + (ComboBox1.SelectedIndex << 3)
        If (M3F20xm_SPISetConfig(byDeviceId, tmp)) Then
            spiCfg.wSPIConfig = tmp.wSPIConfig
            spiCfg.wDelayCSLow = tmp.wDelayCSLow
            spiCfg.wDelayComEnd = tmp.wDelayComEnd
            spiCfg.wDelayDataEnd = tmp.wDelayDataEnd
            spiCfg.wDelayFrameEnd = tmp.wDelayFrameEnd
        Else
            MsgBox("Fail to call M3F20xm_SPISetConfig")
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Dim cfg(2) As Byte
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        If (IsHex(TextBox6.Text) = False) Then
            MsgBox("Please input corrent hex string for GPIO Config ")
            Return
        End If
        If (TextBox6.Text.Length <> 4) Then
            MsgBox("Please input corrent hex string for GPIO Config ")
            Return
        End If
        Str2Val(cfg, TextBox6.Text)
        If (M3F20xm_GPIOSetConfig(byDeviceId, cfg(1) + cfg(0) * 256)) Then
            gpioCfg = cfg(1) + cfg(0) * 256
            M3F20xm_GPIORead(byDeviceId, gpioValue)
            InitControl()
        Else
            MsgBox("Fail to call M3F20xm_GPIOSetConfig")
        End If
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Dim value(1) As Byte
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        If (IsHex(TextBox9.Text) = False) Then
            MsgBox("Please input corrent hex string for GPIO Value ")
            Return
        End If
        If (TextBox9.Text.Length <> 2) Then
            MsgBox("Please input corrent hex string for GPIO Value ")
            Return
        End If
        Str2Val(value, TextBox9.Text)
        If (M3F20xm_GPIOWrite(byDeviceId, value(0), 255)) Then
            gpioValue = value(0)
            InitControl()
        Else
            MsgBox("Fail to call M3F20xm_GPIOWrite")
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        Dim dat() As Byte
        Dim com(16) As Byte
        Dim trigSize, period, trigCnt As UInt32
        Dim wReadSize As UInt16
        Dim str As String
        ReDim dat(64)
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If

        If (RadioButton1.Checked) Then
            dat(0) = trigCfg.byTrigCon Or &H1
        Else
            dat(0) = trigCfg.byTrigCon And &HFE
        End If

        dat(1) = ComboBox3.SelectedIndex
        dat(3) = ComboBox5.SelectedIndex
        str = TextBox13.Text
        If (str.Length = 0) Then
            MessageBox.Show("Please input timer internal")
            Return
        End If
        period = Convert.ToUInt32(str)
        If (ComboBox4.SelectedIndex = 0) Then

            period = period * 1000000

        ElseIf (ComboBox4.SelectedIndex = 1) Then
            period = period * 1000
        Else

        End If
        If (period = 0) Then
            MessageBox.Show("The time period can't be equal to 0")
            Return
        End If
        If (period > 30000000) Then
            MessageBox.Show("The time period can't be large than 30s")
            Return
        End If

        dat(4) = CByte(period)
        dat(5) = CByte(period / 256)
        dat(6) = CByte(period / 256 / 256)
        dat(7) = CByte(period / 256 / 256 / 256)
        str = TextBox4.Text

        If (IsHex(str) = False Or str.Length = 0) Then
            MessageBox.Show("Incorrect format for read command!")
            Return
        End If
        dat(8) = str.Length / 2
        Str2Val(com, str)
        For i = 0 To dat(8) - 1 Step 1
            dat(10 + i) = com(i)
        Next
        str = TextBox7.Text
        If (IsHex(str) = False Or str.Length = 0) Then
            MessageBox.Show("Incorrect format for write command!")
            Return
        End If
        dat(9) = str.Length / 2
        Str2Val(com, str)
        For i = 0 To dat(9) - 1 Step 1
            dat(26 + i) = com(i)
        Next
        If (str.Length = 0) Then
            MessageBox.Show("Please input trig size")
            Return
        End If
        wReadSize = Convert.ToUInt16(str)
        dat(42) = CByte(wReadSize)
        dat(43) = CByte(wReadSize / 256)
        trigSize = Convert.ToUInt32(str)
        If (trigSize > 3072) Then
            MessageBox.Show("The Trig size can't be large than 3072!")
            Return
        End If
        dat(44) = CByte(trigSize)
        dat(45) = CByte(trigSize / 256)

        str = TextBox14.Text
        trigCnt = Convert.ToUInt32(str)
        dat(52) = CByte(trigCnt)
        dat(53) = CByte(trigCnt / 256)
        dat(54) = CByte(trigCnt / 256 / 256)
        dat(55) = CByte(trigCnt / 256 / 256 / 256)
       
        If (M3F20xm_TrigSetConfig(byDeviceId, dat) = False) Then
            MessageBox.Show("Fail to call M3F20xm_TrigSetConfig")
            Return
        End If
        DataArrayToTrigConfig(dat)
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim ReadBuff() As Byte
        Dim WriteBuff() As Byte
        Dim str As String
        If (WriteCnt = 0) Then
            MessageBox.Show("Please input test data")
            Return
        End If
        ReDim ReadBuff(WriteCnt)
        ReDim WriteBuff(WriteCnt)
        Str2Val(WriteBuff, TextBox8.Text)

        If (WriteCnt > MAX_DIR_RW_SIZE) Then
            MessageBox.Show("Test Data can't be large than 48K BYTES")
            Return
        End If

        If (M3F20xm_SPITransfer(byDeviceId, WriteBuff, ReadBuff, WriteCnt, 5000) = False) Then
            MessageBox.Show("Fail to call M3F20xm_SPITransfer!")
            Return
        End If

        str = ""
        Val2Str(str, ReadBuff, WriteCnt, (TextBox3.Text.Length Mod 50))
        TextBox3.Text = TextBox3.Text + str.ToString()
        readCnt = readCnt + WriteCnt
        Label11.Text = readCnt.ToString("00000000")
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim buff() As Byte
        Dim realSize As UInt32
        Dim str As String
        ReDim buff(USB_POLL_SIZE)
        If (M3F20xm_ReadFIFO(byDeviceId, buff, USB_POLL_SIZE, realSize)) Then
            If (realSize > 0) Then
                Str = ""
                Val2Str(str, buff, realSize, (TextBox3.Text.Length Mod 50))
                TextBox3.Text = TextBox3.Text + str.ToString()
                readCnt = readCnt + realSize
                Label11.Text = readCnt.ToString("00000000")
                dwReadSize += realSize
            End If
        End If
    End Sub
    Private Sub ReadLeft()
        Dim leftSize As UInt32
        Dim pBuf() As Byte
        Dim str As String
        leftSize = 0
        If (M3F20xm_GetFIFOLeft(byDeviceId, leftSize)) Then
            If (leftSize = 0) Then
                MessageBox.Show("There is no left byte!")
                Return
            End If
            ReDim pBuf(leftSize)
            If (M3F20xm_ReadFIFO(byDeviceId, pBuf, leftSize, leftSize)) Then
                str = ""
                Val2Str(str, pBuf, leftSize, (TextBox3.Text.Length Mod 50))
                TextBox3.Text = TextBox3.Text + str.ToString()
                readCnt = readCnt + leftSize
                Label11.Text = readCnt.ToString("00000000")
            End If
        Else
            MessageBox.Show("Fail to call M3F20xm_GetLeftSize")
        End If
    End Sub
    Private Sub DataArrayToTrigConfig(ByVal byDatArray() As Byte)
        Dim i As Byte
        i = 0
        trigCfg.byTrigCon = byDatArray(0)
        trigCfg.byIOTrigOptions = byDatArray(1)
        trigCfg.byActions = byDatArray(3)
        trigCfg.dwPeriod = byDatArray(4)
        trigCfg.dwPeriod += (byDatArray(5) * 256)
        trigCfg.dwPeriod += (byDatArray(6) * 256 * 256)
        trigCfg.dwPeriod += (byDatArray(7) * 256 * 256 * 256)
        trigCfg.byRCmdSize = byDatArray(8)
        trigCfg.byWCmdSize = byDatArray(9)
        For i = 10 To 25
            trigCfg.byReadCmd(i - 10) = byDatArray(i)
        Next
        For i = 26 To 41
            trigCfg.byWriteCmd(i - 26) = byDatArray(i)
        Next
        trigCfg.wReadSize = byDatArray(42)
        trigCfg.wReadSize += (byDatArray(43) * 256)
        trigCfg.wTrigSize = byDatArray(44)
        trigCfg.wTrigSize += (byDatArray(45) * 256)
        trigCfg.dwMaxCnt = byDatArray(52)
        trigCfg.dwMaxCnt += (byDatArray(53) * 256)
        trigCfg.dwMaxCnt += (byDatArray(54) * 256 * 256)
        trigCfg.dwMaxCnt += (byDatArray(55) * 256 * 256 * 256)

    End Sub
End Class
