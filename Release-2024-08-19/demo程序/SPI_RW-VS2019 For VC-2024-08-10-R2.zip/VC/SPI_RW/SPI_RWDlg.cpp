// SPI_RWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPI_RW.h"
#include "SPI_RWDlg.h"
#include "AboutDlg.h"
#include <objbase.h>
#include <initguid.h>
#include <Setupapi.h>
#pragma comment(lib, "setupapi.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "M3F20xm.h"


HWND mainhwnd;

void USBIO_Status_Nofiy (BYTE iDevIndex,	DWORD iStatus); 


void USBIO_Status_Nofiy (BYTE iDevIndex,DWORD iStatus)
{
 PostMessage(mainhwnd,WM_USB_STATUS,iDevIndex,iStatus);

}

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg dialog

CSPI_RWDlg::CSPI_RWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSPI_RWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSPI_RWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CSPI_RWDlg::~CSPI_RWDlg()
{
  if(byDevIndex != 0xFF)
  {
  // if(SPI_dev->bRunning)
  //  USBIO_ExitTrig(byDevIndex);   
   M3F20xm_CloseDevice(byDevIndex);
  }
  delete pRWBuf;
}

void CSPI_RWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSPI_RWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSPI_RWDlg, CDialog)
	//{{AFX_MSG_MAP(CSPI_RWDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_CONNECT, OnConnect)
	ON_MESSAGE(WM_USB_STATUS, USB_StatusChange)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
//	ON_CBN_SELCHANGE(IDC_COMBO3, OnSelchangeCombo3)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(ID_CONNECT2, OnConnect2)
	ON_BN_CLICKED(ID_CONNECT4, OnConnect4)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(ID_TEST, &CSPI_RWDlg::OnBnClickedTest)
	ON_BN_CLICKED(IDC_BUTTON11, &CSPI_RWDlg::OnBnClickedButton11)
	ON_WM_TIMER()
//	ON_BN_CLICKED(IDC_BUTTON15, &CSPI_RWDlg::OnBnClickedButton15)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg message handlers

BOOL CSPI_RWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	mainhwnd=GetSafeHwnd(); 
	byDevIndex = 0xFF;
	
	byVerified = 0;
	byGPIOValue = 0;
	dwGPIOConfig = 0;
	pRWBuf = new BuffInfo();
    M3F20xm_SetUSBNotify(false,USBIO_Status_Nofiy);
	InitSPISetting();
    UpdateController();
	//EnumPortsWdm();
	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CSPI_RWDlg::InitSPISetting(void)
{
 memset(&mySPIPara,0,sizeof(SPI_CONFIG));
 mySPIPara.wSPIConfig = 0x04 + 0x20;//master, MSB,1/32 devider
 memset(&myTrigConfig,0,sizeof(TRIG_CONFIG));
 myTrigConfig.byTrigCon = 0;
 myTrigConfig.byIOTrigOptions = 1;
 myTrigConfig.byActions = 0;
 myTrigConfig.dwPeriod = 10000;
 myTrigConfig.wTrigSize = 3072;
 myTrigConfig.dwMaxCnt = 0;
 myTrigConfig.byRCmdSize = 1;
 myTrigConfig.byReadCmd[0] = 0;
 myTrigConfig.byWCmdSize = 1;
 myTrigConfig.byWriteCmd[0] = 0;
 myTrigConfig.wReadSize = 16;
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSPI_RWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSPI_RWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSPI_RWDlg::UpdateController()
{
 char temp[20];
 DWORD factor;
 ((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel((mySPIPara.wSPIConfig & FREQUENCY_BIT) >> 3);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel((mySPIPara.wSPIConfig & 0x03));

 if(mySPIPara.wSPIConfig & DATASIZE_BIT)
  ((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(BST_CHECKED);
 else
  ((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(BST_UNCHECKED);

 if(mySPIPara.wSPIConfig & MODE_BIT)
  ((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(BST_UNCHECKED);
 else
  ((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(BST_CHECKED);

 if(mySPIPara.wSPIConfig & DIR_BIT)
  ((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(BST_CHECKED);
 else
  ((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(BST_UNCHECKED);

 if(mySPIPara.wSPIConfig & ORDER_BIT)
  ((CButton*)GetDlgItem(IDC_CHECK5))->SetCheck(BST_CHECKED);
 else
  ((CButton*)GetDlgItem(IDC_CHECK5))->SetCheck(BST_UNCHECKED);

  sprintf(temp,"%d",mySPIPara.wDelayCSLow);
  ((CEdit*)GetDlgItem(IDC_EDIT11))->SetWindowText(temp);
  sprintf(temp,"%d",mySPIPara.wDelayComEnd);
  ((CEdit*)GetDlgItem(IDC_EDIT12))->SetWindowText(temp);
  sprintf(temp,"%d",mySPIPara.wDelayFrameEnd);
  ((CEdit*)GetDlgItem(IDC_EDIT13))->SetWindowText(temp);
  sprintf(temp,"%d",mySPIPara.wDelayDataEnd);
  ((CEdit*)GetDlgItem(IDC_EDIT15))->SetWindowText(temp);



 ((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(myTrigConfig.byIOTrigOptions);
 ((CComboBox*)GetDlgItem(IDC_COMBO5))->SetCurSel(myTrigConfig.byActions);
 if(myTrigConfig.dwPeriod < 1000)
 {
	((CComboBox*)GetDlgItem(IDC_COMBO4))->SetCurSel(2);
	factor = myTrigConfig.dwPeriod;
 }
 else if(myTrigConfig.dwPeriod < 1000000)
 {
	 ((CComboBox*)GetDlgItem(IDC_COMBO4))->SetCurSel(1);
	 factor = myTrigConfig.dwPeriod / 1000;
 }
 else
 {
	 ((CComboBox*)GetDlgItem(IDC_COMBO4))->SetCurSel(0);
	 factor = myTrigConfig.dwPeriod / 1000000;
 }

 if(myTrigConfig.byTrigCon & 0x01)
 { 
	 ((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(BST_CHECKED);
	 ((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(BST_UNCHECKED);
 }
 else
 {
	 ((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(BST_UNCHECKED);
	 ((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(BST_CHECKED);
 }
 sprintf(temp,"%d",factor);
 ((CEdit*)GetDlgItem(IDC_EDIT14))->SetWindowText(temp);
 ((CComboBox*)GetDlgItem(IDC_COMBO4))->SetCurSel(myTrigConfig.byIOTrigOptions);
 sprintf(temp,"%d",myTrigConfig.wTrigSize);
 ((CEdit*)GetDlgItem(IDC_EDIT16))->SetWindowText(temp);
 sprintf(temp,"%d",myTrigConfig.dwMaxCnt);
 ((CEdit*)GetDlgItem(IDC_EDIT17))->SetWindowText(temp);
 sprintf(temp,"%d",myTrigConfig.wReadSize);
 ((CEdit*)GetDlgItem(IDC_EDIT5))->SetWindowText(temp);
 for(int i = 0; i < myTrigConfig.byRCmdSize; i++)
 {
	 sprintf(&temp[i*2],"%02X",myTrigConfig.byReadCmd[i]);
 }
 ((CEdit*)GetDlgItem(IDC_EDIT4))->SetWindowText(temp);
 for(int i = 0; i < myTrigConfig.byWCmdSize; i++)
 {
	 sprintf(&temp[i*2],"%02X",myTrigConfig.byWriteCmd[i]);
 }
 ((CEdit*)GetDlgItem(IDC_EDIT9))->SetWindowText(temp);

  sprintf(temp,"%04X",dwGPIOConfig);
  ((CEdit*)GetDlgItem(IDC_EDIT7))->SetWindowText(temp);
  sprintf(temp,"%02X",byGPIOValue);
  ((CEdit*)GetDlgItem(IDC_EDIT8))->SetWindowText(temp);

 ((CComboBox*)GetDlgItem(IDC_COMBO1))->EnableWindow(byVerified);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->EnableWindow(byVerified);


 ((CButton*)GetDlgItem(IDC_BUTTON10))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(byVerified);

 ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_BUTTON3))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_BUTTON11))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_CHECK1))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_CHECK3))->EnableWindow(byVerified);
 ((CButton*)GetDlgItem(IDC_CHECK5))->EnableWindow(byVerified);
 
 ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(byVerified);

 ((CEdit*)GetDlgItem(IDC_EDIT7))->EnableWindow(byVerified);
 ((CEdit*)GetDlgItem(IDC_EDIT8))->EnableWindow(byVerified);


 if(byDevIndex == 0xFF)  
 {
  ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
  SetWindowText("SPI��д��ʾ����<---->�豸δ����");	   
  GetDlgItem(ID_CONNECT)->SetWindowText("����");
 }
 else
 {
  GetDlgItem(ID_CONNECT)->SetWindowText("�Ͽ�");
  if(myTrigConfig.byTrigCon & 0x80)     //trig mode
  	  ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("ֹͣ����");
  else
     ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");

 }
}

//void CSPI_RWDlg::OnQuit() 
//{
// 
//}

void CSPI_RWDlg::OnConnect() 
{
  char serial[15] = {0};
  if(byDevIndex != 0xFF)
  {
    if(myTrigConfig.byTrigCon & 0x80)   //trig mode
    {
     M3F20xm_EnableTrig(byDevIndex,0);
     myTrigConfig.byTrigCon &= 0x7F;
   	 KillTimer(1);
     Sleep(10);
     ReadLeft();
     }
	 if(M3F20xm_CloseDevice(byDevIndex) == false)
     {
		MessageBox("�ر��豸ʧ��!");
		return;
	 }
	    byDevIndex = 0xFF;   
		byVerified = 0;
  	}
	else
	{
     byDevIndex = M3F20xm_OpenDevice();
	 if(byDevIndex == 0xFF)
	 {
  		MessageBox("���豸ʧ��!");
		return ;
	 }
	else
	{
 
	  if(!M3F20xm_Verify(byDevIndex,&byVerified))
	  {
		  MessageBox("�豸��֤ʧ��!");
		  M3F20xm_CloseDevice(byDevIndex);
		  byDevIndex = 0xFF;
		  return ;
	  }

	  if(byVerified)
	  {
	   M3F20xm_GPIOGetConfig(byDevIndex,&dwGPIOConfig);
       M3F20xm_GPIORead(byDevIndex,&byGPIOValue);
	   M3F20xm_SPIGetConfig(byDevIndex,&mySPIPara);
	   M3F20xm_TrigGetConfig(byDevIndex,&myTrigConfig);
	  }	  
	  M3F20xm_GetSerialNo(byDevIndex,serial);
	  SetWindowText(serial);

 	}
	}	
	UpdateController();
}

LRESULT CSPI_RWDlg::USB_StatusChange(WPARAM wParam, LPARAM lParam)
{
  if(lParam&0x80)                    //usb dev plugged
  {

  }
  else
  {
	 if(byDevIndex == wParam)
	   {
		byDevIndex = 0xFF;
     	UpdateController();
	   }
  }
  return 0;
}




void CSPI_RWDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
  DWORD dwTimeout;
  CString str;
  BYTE byRate;
  char Buff[100];
  SPI_CONFIG cfg;
  memcpy(&cfg,&mySPIPara,sizeof(SPI_CONFIG));
  cfg.wSPIConfig = (cfg.wSPIConfig & (~FREQUENCY_BIT)) + (((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel() << 3);
  cfg.wSPIConfig = (cfg.wSPIConfig & 0xFFFE) + (((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel());
  if(((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() ==  BST_UNCHECKED)
     cfg.wSPIConfig &= (~DATASIZE_BIT);
  else
     cfg.wSPIConfig |= DATASIZE_BIT;
 
  if(((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck() ==  BST_UNCHECKED)
     cfg.wSPIConfig |= MODE_BIT;
  else
     cfg.wSPIConfig &= (~MODE_BIT);
 
  if(((CButton*)GetDlgItem(IDC_CHECK3))->GetCheck() ==  BST_UNCHECKED)
     cfg.wSPIConfig &= (~DIR_BIT);
  else
     cfg.wSPIConfig |= DIR_BIT;
 
  if(((CButton*)GetDlgItem(IDC_CHECK5))->GetCheck() ==  BST_UNCHECKED)
     cfg.wSPIConfig &= (~ORDER_BIT);
  else
     cfg.wSPIConfig |= ORDER_BIT;
 
  ((CEdit*)GetDlgItem(IDC_EDIT11))->GetWindowText(str);
  if(!str.IsEmpty())
  {
	  cfg.wDelayCSLow = _ttoi(str);
  }

  ((CEdit*)GetDlgItem(IDC_EDIT12))->GetWindowText(str);
  if(!str.IsEmpty())
  {
	  cfg.wDelayComEnd = _ttoi(str);
  }

    ((CEdit*)GetDlgItem(IDC_EDIT13))->GetWindowText(str);
  if(!str.IsEmpty())
  {
	  cfg.wDelayFrameEnd = _ttoi(str);
  }

    ((CEdit*)GetDlgItem(IDC_EDIT15))->GetWindowText(str);
  if(!str.IsEmpty())
  {
	  cfg.wDelayDataEnd = _ttoi(str);
  }

  if(!M3F20xm_SPISetConfig(byDevIndex,&cfg))
 {
   MessageBox("����ʧ��");
   return;
 }
 if((mySPIPara.wSPIConfig & MODE_BIT) && !(cfg.wSPIConfig & MODE_BIT))     //enter slaver mode
   {
     M3F20xm_InitFIFO(byDevIndex);
     dwReadSize = 0;
     SetTimer(1,20,0);
 }
 else if(!(mySPIPara.wSPIConfig & MODE_BIT) && (cfg.wSPIConfig & MODE_BIT)) //exit slaver mode
   {
   KillTimer(1);
   Sleep(10);
   ReadLeft();
   }
 memcpy(&mySPIPara,&cfg,sizeof(SPI_CONFIG));
 UpdateController();
}


void CSPI_RWDlg::OnButton6() 
{
// TODO: Add your control notification handler code here
 
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
 pEdit->SetWindowText("");
 
 pRWBuf->ReadBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",0);
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
}

void CSPI_RWDlg::OnButton10() 
{
	// TODO: Add your control notification handler code here
 AboutDlg Dlg(this,byDevIndex);
 Dlg.DoModal();
	
}

//void CSPI_RWDlg::OnSelchangeCombo3() 
//{
//
// 
//
//}

//void CSPI_RWDlg::OnCheck2() 
//{
//	// TODO: Add your control notification handler code here
//  CButton *pbox = (CButton*)GetDlgItem(IDC_CHECK2);
//
//	USBIO_SetCE(byDevIndex,pbox->GetCheck() == 1);
//
//}

void CSPI_RWDlg::OnButton3() 
{
 BYTE byTriged = myTrigConfig.byTrigCon & 0x80;
 if(byTriged)
 {
  if(M3F20xm_EnableTrig(byDevIndex,0))
  {
    myTrigConfig.byTrigCon &= 0x7F;
   	KillTimer(1);
    Sleep(10);
    ReadLeft();
  }
  else
    MessageBox("���ú��� M3F20xm_EnableTrig 0ʧ��!");
 }
 else
 {
   if(M3F20xm_EnableTrig(byDevIndex,1))
   {
    myTrigConfig.byTrigCon |= 0x80;
    M3F20xm_InitFIFO(byDevIndex);
    SetTimer(1,500,0);
	dwReadSize = 0;
   }
  else
    MessageBox("���ú��� M3F20xm_EnableTrig 1ʧ��!");
 }
 UpdateController();	
}

//---------------------------------------------------------------------------
void CSPI_RWDlg::ReadLeft()
{	
 DWORD  leftSize;
 char Temp[12];
 if(M3F20xm_GetFIFOLeft(byDevIndex,&leftSize))
 {
  if(leftSize == 0)
    return;
  BYTE* pBuf = new BYTE[leftSize];
  if(M3F20xm_ReadFIFO(byDevIndex,pBuf,leftSize,&leftSize))
  {
   pRWBuf->PutReadBuf(pBuf,leftSize);
   sprintf(Temp,"%08d",pRWBuf->GetReadCnt());
   ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Temp);
   ApplendText(IDC_EDIT3,pBuf,leftSize);

 
  }
  delete []pBuf;
 }
 else
   MessageBox("���ú���M3F20xm_GetLeftSizeʧ��");
}
//---------------------------------------------------------------------------
void CSPI_RWDlg::DoReadBuff(void)
{
 CString str;
 WORD offset;
 BYTE buff[3072];
 char Buff[12];

 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(str.IsEmpty())
 {
   MessageBox("������buff��ʼ��ַ!");
   return;
 }

 offset = _ttoi(str);
 
 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);

 DWORD dwReadLen = _ttoi(str);
 

 
 if(dwReadLen == 0)
 {
  MessageBox("�����������!");
  return;
 }
 if(dwReadLen + offset > USB2SPI_BUFFSIZE)
 {
  MessageBox("�����Ȳ��ܳ���buff����(3072)!");
  return;
 }
 if(!M3F20xm_BuffRead(byDevIndex,offset,buff,dwReadLen,200))
 {
  MessageBox("���ú���M3F20xm_BuffReadʧ��!");
 }
 else
 {
  pRWBuf->PutReadBuf(buff,dwReadLen);
  sprintf(Buff,"%08d",pRWBuf->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
 ApplendText(IDC_EDIT3,buff,dwReadLen);
 }
}

void CSPI_RWDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE* pTmpBuff;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }
 if((mySPIPara.wSPIConfig & MODE_BIT) == 0)
 {
   DoReadBuff();
   return;
 }

 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
 char Buff[100]={0};

 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);
 if(str.IsEmpty())
 {
    MessageBox("�����������!");
	return;
 }

 DWORD dwReadLen = _ttoi(str);
 if(mySPIPara.wSPIConfig & DIR_BIT)   //direct
 {
  
  if(dwReadLen > MAX_DIR_RW_SIZE)
   dwReadLen = MAX_DIR_RW_SIZE;

 }
 else
 {

  if(dwReadLen > MAX_DMA_RW_SIZE)
   dwReadLen = MAX_DMA_RW_SIZE;

 }
 
 pTmpBuff = new BYTE[dwReadLen];
 if(M3F20xm_SPIRead(byDevIndex,Temp,comLen,pTmpBuff,dwReadLen,5000)==0)
 {
	delete []pTmpBuff;
	MessageBox("��ʧ��!");
	return;
 }
 pRWBuf->PutReadBuf(pTmpBuff,dwReadLen);
 sprintf(Buff,"%08d",pRWBuf->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
 ApplendText(IDC_EDIT3,pTmpBuff,dwReadLen);
 delete []pTmpBuff;
}

//---------------------------------------------------------------------------
void CSPI_RWDlg::DoWriteBuff(void)
{
  CString str;
  WORD offset;
  char Buff[12];

 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(str.IsEmpty())
 {
   MessageBox("������buff��ʼ��ַ!");
   return;
 } 
 offset = _ttoi(str);

 if(pRWBuf->GetWriteCnt() == 0)
 {
  MessageBox("������д������!");
  return;
 }
 if(pRWBuf->GetWriteCnt() + offset > USB2SPI_BUFFSIZE)
 {
  MessageBox("д���ݳ��Ȳ��ܳ���buff����(3072)!");
  return;
 }
 if(!M3F20xm_BuffWrite(byDevIndex,offset,pRWBuf->GetWriteBuf(),pRWBuf->GetWriteCnt(),200))
 {
  MessageBox("���ú���M3F20xm_BuffWriteʧ��!");
 }
}

void CSPI_RWDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 DWORD dwWriteSize;
 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }	

 if((mySPIPara.wSPIConfig & MODE_BIT) == 0)
 {
   DoWriteBuff();
   return;
 }
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);

 dwWriteSize = pRWBuf->GetWriteCnt();
 if(mySPIPara.wSPIConfig & DIR_BIT)   //direct
 {
  
  if(dwWriteSize > MAX_DIR_RW_SIZE)
  {
   MessageBox("д�볤�Ȳ��ܴ���48K!");  
  }

 }
 else
 {

  if(dwWriteSize > MAX_DMA_RW_SIZE)
  {
	 MessageBox("д�볤�Ȳ��ܴ���2M!");
	 return;
  }
 }


 if(M3F20xm_SPIWrite(byDevIndex,Temp,comLen,pRWBuf->GetWriteBuf(),dwWriteSize,5000)==0)
 {
	MessageBox("дʧ��!");
	return;
 }
 
}

bool CSPI_RWDlg::IsHexString(CString str)
{
 int len = str.GetLength();
 if(len == 0)
	return true;
 if(len % 2 || len > 256)
	return false;
 
 for(int i = 0 ; i < len ; i ++)
 {
	 if(str[i] >= '0' &&  str[i] <= '9')
		 continue;
	 else if(str[i] >= 'a' &&  str[i] <= 'f')
		 continue;
	 else if(str[i] >= 'A' &&  str[i] <= 'F')
		 continue;
	 else
		 return false;
 }
 return true;
}

void CSPI_RWDlg::StrToVal(BYTE *pByte, CString &str)
{
	int i,j;
    int len = str.GetLength()/2;
	
	for(i=0,j=0;j<len;i++,j++)
	{
		pByte[j] = (BYTE)((CharToBcd(str[i])<<4) + CharToBcd(str[i+1]));
		i++;
	}
}

void CSPI_RWDlg::VarToStr(CString &str,BYTE *pByte, int len,BYTE start)
{
 str.Empty();
 CString tempStr;
 for(int i = 0 ,j = start; i < len ; i++)
 {
   str += " ";
   //str += CString(BcdToChar(pByte[i] >> 4));
   //str += CString(BcdToChar(pByte[i] & 0x0F));
   tempStr.Format(_T("%02X"),pByte[i]);
   str = str + tempStr; 
   j += 3;
   if( j == 48)
   {
	   str += L"\r\n";
	   j = 0;
   }
 }
}


BYTE CSPI_RWDlg::BcdToChar(BYTE iBcd)
{
	BYTE hexVar[] = {"0123456789ABCDEF"};
    return hexVar[iBcd];
}

BYTE CSPI_RWDlg::CharToBcd(BYTE iChar)
{
	UCHAR	mBCD;
	if ( iChar >= '0' && iChar <= '9' ) mBCD = iChar -'0';
	else if ( iChar >= 'A' && iChar <= 'F' ) mBCD = iChar - 'A' + 0x0a;
	else if ( iChar >= 'a' && iChar <= 'f' ) mBCD = iChar - 'a' + 0x0a;
	else mBCD = 0x00;
	return( mBCD );
}


void CSPI_RWDlg::ApplendText(int id, BYTE *pByte, int len)
{
  CEdit* pEdit = (CEdit*)GetDlgItem(id);
  CString str;
  DWORD textLen = pEdit->GetWindowTextLength();
  BYTE start = textLen % 50;
  VarToStr(str,pByte,len,start);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel(str);
}

void CSPI_RWDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
   CString FileName;
   if(pRWBuf->GetReadCnt() == 0)
   {
	   MessageBox("��������Ϊ��!");
	   return;
   }
   CFileDialog* p = new CFileDialog(false,"*.bin",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName = p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}

	    CFile file(FileName,CFile::modeCreate|CFile::modeWrite);

		file.Write(pRWBuf->GetReadBuf() ,pRWBuf->GetReadCnt() );//д�ļ���־
		file.Close();
   }
   delete p;	
}

void CSPI_RWDlg::OnButton9() 
{
	// TODO: Add your control notification handler code here
   CString FileName;
   CFileDialog* p=new CFileDialog(true,"*.bin",NULL,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName=p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}
	    CFile file(FileName,CFile::modeRead);
        DWORD fileLen = file.GetLength();
		if(fileLen == 0)
		{
			delete p;
			MessageBox("�յ��ļ�!");
			return;
		}
		
		OnButton8();
		BYTE* pBuf = new BYTE[fileLen + 1];
		file.Read(pBuf,fileLen);//д�ļ���־
		pRWBuf->WriteBufUpdate(pBuf,fileLen);
		file.Close();
		delete pBuf;
		ApplendText(IDC_EDIT6,pRWBuf->GetWriteBuf(),pRWBuf->GetWriteCnt());
		char Buff[20];
		sprintf(Buff,"%08d",fileLen);
        ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
   }
   delete p;		
}

void CSPI_RWDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT6);
 pEdit->SetWindowText(""); 

 char Buff[20];
 pRWBuf->WriteBufClear();
 sprintf(Buff,"%08d",0);
 ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
}


//#ifndef GUID_CLASS_COMPORT
//DEFINE_GUID(GUID_CLASS_COMPORT, 0x86e0d1e0L, 0x8089, 0x11d0, 0x9c, 0xe4, 0x08, 0x00, 0x3e, 0x30, 0x1f, 0x73);
  DEFINE_GUID(GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR, 0x4D36E978L, 0xE325, 0x11CE, 0xBF, 0xC1, 0x08, 0x00, 0x2B, 0xE1, 0x03, 0x18);
  DEFINE_GUID(GUID_DEVINTERFACE_USB2INTERFACE,0xA5DCBF10, 0x6530, 0x11D2, 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED);
  //4D36E978-E325-11CE-BFC1-08002BE10318
//#endif
void CSPI_RWDlg::EnumPortsWdm(void)
{
 DWORD      bufferSize;
 HDEVINFO   hDeviceInfo;
 SP_DEVICE_INTERFACE_DATA            interfaceData;
 PSP_DEVICE_INTERFACE_DETAIL_DATA    deviceDetail;
 GUID guid = GUID_DEVINTERFACE_USB2INTERFACE;// GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR;
 hDeviceInfo = SetupDiGetClassDevs(
                    //(LPGUID)&GUID_DEVINTERFACE_USB2INTERFACE,
                    &guid,
                    NULL,
                    NULL,
                    DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
                    );
 
  if (hDeviceInfo == INVALID_HANDLE_VALUE)
    {
      MessageBox( "can't find usb device!!!");
      return ;
    }
    // Setup the interface data struct
    interfaceData.cbSize = sizeof(interfaceData);
    int ii,jj;
	jj = 0;
    for (ii = 0;SetupDiEnumDeviceInterfaces(
            hDeviceInfo,
            NULL,
           // (LPGUID)&GUID_DEVINTERFACE_USB2INTERFACE,
            &guid,
            ii,
            &interfaceData);
         ++ii)
    {
        // Found our device instance
      //  LogPrintf( "%s\n","Found our device instance");
        if (!SetupDiGetDeviceInterfaceDetail(
                hDeviceInfo,
                &interfaceData,
                NULL,
                0,
                &bufferSize,
                NULL))
        {
            if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
            {
                MessageBox("Error: couldn't get interface detail");

                continue;
            }
        }

        // Allocate a big enough buffer to get detail data
        deviceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(bufferSize);
        if (deviceDetail == NULL)
        {
            MessageBox("Error: Buffer allocation failed");
            continue;
        }

        // Setup the device interface struct
        deviceDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        // Try again to get the device interface detail info
        if (!SetupDiGetDeviceInterfaceDetail(
                hDeviceInfo,
                &interfaceData,
                deviceDetail,
                bufferSize,
                NULL,
                NULL))
        {
            MessageBox("Error: SetupDiGetDeviceInterfaceDetail failed ");
            free(deviceDetail);
            continue;
        }
    
        free(deviceDetail);
    }
    SetupDiDestroyDeviceInfoList(hDeviceInfo);

}

void CSPI_RWDlg::OnConnect2() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
  CString str;
  BYTE byConfig[2];
  char Buff[100];
 ((CEdit*)GetDlgItem(IDC_EDIT7))->GetWindowText(str);
 if(IsHexString(str) == false || str.GetLength() != 4)
 {
  MessageBox("������hex��ʽ�ҳ���Ϊ4!");
  return;
 }
  StrToVal(byConfig,str); 

 if(M3F20xm_GPIOSetConfig(byDevIndex,byConfig[0] * 256 + byConfig[1]))
 {   
   dwGPIOConfig = byConfig[0] * 256 + byConfig[1];
   M3F20xm_GPIORead(byDevIndex,&byGPIOValue);
   MessageBox("����ok");
 }
 UpdateController();	
}

//void CSPI_RWDlg::OnConnect3() 
//{
//	// TODO: Add your control notification handler code here
// BYTE byAddr;
// if(USBIO_GPIORead(byDevIndex,&byAddr))
// {
//	 GPIO_dev->byRateIndex = byAddr;
//	 UpdateController();	
// }
// 
//}

void CSPI_RWDlg::OnConnect4() 
{
	// TODO: Add your control notification handler code here
  CString str;
  BYTE byValue;
  char Buff[100];
 ((CEdit*)GetDlgItem(IDC_EDIT8))->GetWindowText(str);
 if(IsHexString(str) == false || str.GetLength() != 2)
 {
  MessageBox("������hex��ʽ�ҳ���Ϊ2!");
  return;
 }
  StrToVal(&byValue,str); 	
  if(M3F20xm_GPIOWrite(byDevIndex,byValue,0xFF))
  {
   M3F20xm_GPIORead(byDevIndex,&byGPIOValue);
   UpdateController();
  }
}


void CSPI_RWDlg::OnBnClickedTest()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
 BYTE ReadData[MAX_DIR_RW_SIZE];
 BYTE* pBuf;
 DWORD size;
 WORD testSize;
 char buff[12]={0};
 pBuf = pRWBuf->GetWriteBuf();
 size = pRWBuf->GetWriteCnt();
 
 if(size == 0)
 {
  MessageBox("�������������");
  return;
  }
 if(size > MAX_DIR_RW_SIZE)
 {
  MessageBox("�������ݲ��ܴ���48K BYTES");
  return;
  }
 
 if(!M3F20xm_SPITransfer(byDevIndex,pRWBuf->GetWriteBuf(),ReadData,size,2000))
  {
   MessageBox("���ú���M3F20xm_SPITransfer!ʧ��");
   return;
  }

  pRWBuf->PutReadBuf(ReadData,size);
  sprintf(buff,"%08d",pRWBuf->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(buff);
 ApplendText(IDC_EDIT3,ReadData,size);
}


void CSPI_RWDlg::OnBnClickedButton11()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
 TRIG_CONFIG tempCfg;
 DWORD temp1;
 DWORD temp2;
 DWORD trigSize;
 DWORD period;
 CString str;
 memset(&tempCfg,0,sizeof(TRIG_CONFIG));
 if(((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck())
    tempCfg.byTrigCon = 0x01;
 tempCfg.byIOTrigOptions = ((CComboBox*)GetDlgItem(IDC_COMBO3))->GetCurSel();
 tempCfg.byActions = ((CComboBox*)GetDlgItem(IDC_COMBO5))->GetCurSel();
 ((CEdit*)GetDlgItem(IDC_EDIT14))->GetWindowText(str);
 if(str.IsEmpty())
 {
   MessageBox("�����붨ʱ���");
   return ;
 }
 period = _ttoi(str);
 if(((CComboBox*)GetDlgItem(IDC_COMBO4))->GetCurSel() == 0)
 {
	 tempCfg.dwPeriod = period * 1000000;
 }
 else if(((CComboBox*)GetDlgItem(IDC_COMBO4))->GetCurSel() == 1)
 {
	 tempCfg.dwPeriod = period * 1000;
 }
 else
 {
	tempCfg.dwPeriod = period ;
 }
 if(tempCfg.dwPeriod == 0)
 {
   MessageBox("��ʱ�������Ϊ0");
   return ;
 }
 if(tempCfg.dwPeriod > 30000000)
 {
   MessageBox("��ʱ������ܴ���30s");
   return ;
 }
 ((CEdit*)GetDlgItem(IDC_EDIT16))->GetWindowText(str);
 if(str.IsEmpty())
 {
   MessageBox("�����봥����С");
   return ;
 }
 trigSize = _ttoi(str);
 if(trigSize > 3072)
 {
   MessageBox("������С���ܴ���3072!");
   return ;
 }
 tempCfg.wTrigSize = trigSize;

 ((CEdit*)GetDlgItem(IDC_EDIT17))->GetWindowText(str);
 if(str.IsEmpty())
 {
   MessageBox("�����봥������");
   return ;
 }
 tempCfg.dwMaxCnt = _ttoi(str);

 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(IsHexString(str) == false || str.IsEmpty())
 {
  MessageBox("�������������ȷ!");
  return;
 }
 tempCfg.byRCmdSize = str.GetLength()/2;
 StrToVal(tempCfg.byReadCmd,str);

 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);
  if(str.IsEmpty())
 {
  MessageBox("�����������!");
  return;
 }
 tempCfg.wReadSize = _ttoi(str);
 if(tempCfg.wReadSize == 0)
 {
   MessageBox("�����Ȳ���Ϊ0!");
   return ;
 }

 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(IsHexString(str) == false || str.IsEmpty())
 {
  MessageBox("д�����������ȷ!");
  return;
 }
 tempCfg.byWCmdSize = str.GetLength()/2;
 StrToVal(tempCfg.byWriteCmd,str);

 if(!M3F20xm_TrigSetConfig(byDevIndex,&tempCfg))
 {
   MessageBox("���ú���M3F20xm_TrigSetConfigʧ��");
   return ;
 }
 memcpy(&myTrigConfig,&tempCfg,sizeof(TRIG_CONFIG));
}


void CSPI_RWDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
 BYTE buff[USB_POLL_SIZE];
 DWORD realSize;
 char Temp[12];
 if(M3F20xm_ReadFIFO(byDevIndex,buff,USB_POLL_SIZE,&realSize))
 {
   if(realSize)
   {
	pRWBuf->PutReadBuf(buff,realSize);
	sprintf(Temp,"%08d",pRWBuf->GetReadCnt());
    ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Temp);
     ApplendText(IDC_EDIT3,buff,realSize);

   }
 }
 if(myTrigConfig.byTrigCon & 0x80)     //trig mode
 {
  if(myTrigConfig.dwMaxCnt && myTrigConfig.dwMaxCnt == dwReadSize / myTrigConfig.wReadSize)
  {
    myTrigConfig.byTrigCon &= 0x7F;
    UpdateController();
    return;
  }
 }
 //SetTimer(1,50,0);
 CDialog::OnTimer(nIDEvent);
}


void CSPI_RWDlg::OnBnClickedButton14()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	M3F20xm_InitFIFO(byDevIndex);
}


//void CSPI_RWDlg::OnBnClickedButton15()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
//	DWORD leftsize,RealSize,total;
//	M3F20xm_GetFIFOLeft(byDevIndex,&leftsize);
//	CString str;
//	str.Format("Get Left Size = 0x%x",leftsize);
//    MessageBox(str);
//	BYTE pBuf[65536];
//	total = 0;
//	while(M3F20xm_ReadFIFO(byDevIndex,pBuf,65536,&RealSize))
//	{
//	total += RealSize;
//	if(0 == RealSize)
//	{
//		MessageBox("Read end");
//		break;
//	}
//	}
//	str.Format("Total Read Size = 0x%x",total);
//    MessageBox(str);
//
//}
