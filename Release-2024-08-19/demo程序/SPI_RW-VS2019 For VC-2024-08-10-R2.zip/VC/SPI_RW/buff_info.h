#ifndef DEV_INFO_H
#define DEV_INFO_H

#include "stdafx.h"


class BuffInfo
{
 public:
	 BuffInfo();
	~BuffInfo();
 private:
	DWORD dwReadCnt;
	BYTE* pReadBuf;
	DWORD dwWriteCnt;
	BYTE* pWriteBuf;
 public:
	bool bRunning;
	void* pMyData;	
	DWORD GetReadCnt();
	DWORD GetWriteCnt();
	BYTE* GetReadBuf();
	BYTE* GetWriteBuf();
	void* GetData();
	void  SetData(void* pData);
	void PutReadBuf(BYTE* pStr,DWORD dwLen);
	void WriteBufUpdate(BYTE* pStr,DWORD dwLen);
	void ReadBufClear();
	void WriteBufClear();
};

#endif

