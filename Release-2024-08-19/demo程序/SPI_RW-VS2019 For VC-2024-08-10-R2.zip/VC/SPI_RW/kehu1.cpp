// SPI_RWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPI_RW.h"
#include "SPI_RWDlg.h"
#include "AboutDlg.h"
#include <objbase.h>
#include <initguid.h>
#include <Setupapi.h>
#pragma comment(lib, "setupapi.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "usbio.h"


HWND mainhwnd;

void CALLBACK USBIO_Status_Nofiy (BYTE iDevIndex,	DWORD iStatus); 
void CALLBACK USBIO_Trig_Nofiy (BYTE iDevIndex,     DWORD	iStatus); 

void CALLBACK USBIO_Status_Nofiy (BYTE iDevIndex,DWORD	iStatus)
{
 PostMessage(mainhwnd,WM_USB_STATUS,iDevIndex,iStatus);
}

//---------------------------------------------------------------------------
void CALLBACK USBIO_Trig_Nofiy (BYTE iDevIndex, DWORD	iStatus)
{
 PostMessage(mainhwnd,WM_USB_TRIG,iDevIndex,iStatus);
}

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg dialog

CSPI_RWDlg::CSPI_RWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSPI_RWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSPI_RWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CSPI_RWDlg::~CSPI_RWDlg()
{
  if(byDevIndex != 0xFF)
  {
   if(SPI_dev->bRunning)
    USBIO_ExitTrig(byDevIndex);   
   USBIO_CloseDevice(byDevIndex);
  }
  delete SPI_dev;
  delete TRIG_dev;

}

void CSPI_RWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSPI_RWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSPI_RWDlg, CDialog)
	//{{AFX_MSG_MAP(CSPI_RWDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_QUIT, OnQuit)
	ON_BN_CLICKED(ID_CONNECT, OnConnect)
	ON_MESSAGE(WM_USB_STATUS, USB_StatusChange)
	ON_MESSAGE(WM_USB_TRIG, USB_Interupter)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_CBN_SELCHANGE(IDC_COMBO3, OnSelchangeCombo3)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg message handlers

BOOL CSPI_RWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	mainhwnd=GetSafeHwnd(); 
	dwWriteIndex = 0;
	byDevIndex = 0xFF;
	SPI_dev = new DevInfo(DEV_SPI);
    SPI_dev->byRateIndex = 0x04;
    SPI_dev->dwTimeout = 0x00C8000C8;
    TRIG_dev = new DevInfo(DEV_TRIG);
    TRIG_dev->byRateIndex = 0;
    USBIO_SetUSBNotify(false,USBIO_Status_Nofiy);
    UpdateController();
	EnumPortsWdm();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSPI_RWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSPI_RWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSPI_RWDlg::UpdateController()
{
 char temp[20];
 ((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(SPI_dev->byRateIndex & 0x0F);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel((SPI_dev->byRateIndex & 0x7F) >> 4);
 ((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(SPI_dev->byRateIndex >> 7);

 sprintf(temp,"%d",SPI_dev->dwTimeout & 0xFFFF);
 ((CEdit*)GetDlgItem(IDC_EDIT1))->SetWindowText(temp);
 sprintf(temp,"%d",SPI_dev->dwTimeout >> 16);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->SetWindowText(temp);

  ((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(TRIG_dev->byRateIndex);


 ((CComboBox*)GetDlgItem(IDC_COMBO1))->EnableWindow(byDevIndex != 0xFF);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->EnableWindow(byDevIndex != 0xFF);


 ((CEdit*)GetDlgItem(IDC_EDIT1))->EnableWindow(byDevIndex != 0xFF);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON10))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(byDevIndex != 0xFF);

 ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON3))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK1))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK3))->EnableWindow(byDevIndex != 0xFF);
 ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(byDevIndex != 0xFF);

 if(byDevIndex != 0xFF)  //SPI is slaver at connected 
 {
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT4))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT5))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT9))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 }

}

void CSPI_RWDlg::OnQuit() 
{
 OnOK();	
}

void CSPI_RWDlg::OnConnect() 
{
  char serial[15] = {0};
  if(byDevIndex != 0xFF)
	{
	  if(SPI_dev->bRunning)
	  {
       if(USBIO_ExitTrig(byDevIndex))
	   {
	     TRIG_dev->bRunning = false;
	     SPI_dev->bRunning = false;
         ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
	   }
	   else
	   {
			MessageBox("�˳�����ʧ��!");
			return;
	   }
	  }
	   if(USBIO_CloseDevice(byDevIndex) == false)
        {
			MessageBox("�ر��豸ʧ��!");
			return;
		}
	    byDevIndex = 0xFF;        
        GetDlgItem(ID_CONNECT)->SetWindowText("����");
		SetWindowText("SPI��д��ʾ����<---->�豸δ����");
	}
	else
	{
     byDevIndex = USBIO_OpenDevice();
	 if(byDevIndex == 0xFF)
	 {
  		MessageBox("���豸ʧ��!");
		return ;
	 }
	else
	{
      GetDlgItem(ID_CONNECT)->SetWindowText("�Ͽ�");
	  USBIO_GetSerialNo(byDevIndex,serial);
	  SetWindowText(serial);

	   USBIO_SetTrigNotify(byDevIndex,USBIO_Trig_Nofiy);   //ע�����֪ͨ  


//	  USBIO_I2cGetConfig(byIndex,&I2C_dev->byDevAddr,&I2C_dev->byRateIndex,&I2C_dev->dwTimeout);
      USBIO_SPIGetConfig(byDevIndex,&SPI_dev->byRateIndex,&SPI_dev->dwTimeout);

	  USBIO_TrigGetConfig(byDevIndex,&TRIG_dev->byRateIndex);

 	}
	}	
	UpdateController();
}

LRESULT CSPI_RWDlg::USB_StatusChange(WPARAM wParam, LPARAM lParam)
{
  if(lParam&0x80)                    //usb dev plugged
  {
/*	if(byDevIndex != 0xFF)
    {
		return 0;
	}
	OnConnect();*/
  }
  else
  {
	 if(byDevIndex == wParam)
	   {
        TRIG_dev->bRunning = false;
	    SPI_dev->bRunning = false;
        ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
	  	SetWindowText("SPI��д��ʾ����<---->�豸δ����");	   
		USBIO_CloseDevice(byDevIndex);
		byDevIndex = 0xFF;
		GetDlgItem(ID_CONNECT)->SetWindowText("����");
		UpdateController();
	   }
  }
  return 0;
}

LRESULT CSPI_RWDlg::USB_Interupter(WPARAM wParam, LPARAM lParam)
{
 BYTE Flag = lParam & 0xFF;
 if(wParam != byDevIndex)
   return 0;
 WORD Length = ((wParam & 0xFF00) >> 8);
 switch (Flag)
 {
	case EXT_IO_TRIG:
		USB_IO_Trigged();
	break;
	case SPI_READ_TRIG:
		USB_SendData(Length);
	break;
	case SPI_WRITE_TRIG:
		USB_ReciData(Length);
	break;
	case SPI_INIT_WRITE_TRIG:
	break;
	case SPI_INIT_READ_TRIG:
		dwWriteIndex = 0;
        USB_SendData(0);
	break;
	default:
	break;
 }
 return 0;
}

void CSPI_RWDlg::USB_IO_Trigged()
{

 if(SPI_dev->bRunning)
 {
  if(((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() == 1)
	OnButton4();
  else
    OnButton5();
  if(USBIO_WaitForTrig(byDevIndex)==false)
  {
   MessageBox("��������ʧ��!");
   TRIG_dev->bRunning = false;
   SPI_dev->bRunning = false;
   ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
   ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(true);
//   ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(true);
   ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(true);
  }
 }

// return 0;
}

void CSPI_RWDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
  DWORD dwTimeout;
  CString str;
  BYTE byRate;
  char Buff[100];

  byRate = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel() + (((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel() << 4);
  CButton *pBox = (CButton*)GetDlgItem(IDC_CHECK3);
  if(pBox->GetCheck() == 1)
	byRate = byRate + 0x80;
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT1);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = atoi(Buff);

  pEdit = (CEdit*)GetDlgItem(IDC_EDIT2);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = dwTimeout + (atoi(Buff)<<16);
 
 if(USBIO_SPISetConfig(byDevIndex,byRate,dwTimeout))
 {
   SPI_dev->byRateIndex = byRate;
   SPI_dev->dwTimeout = dwTimeout;
   MessageBox("����ok");
 }
 UpdateController();
}

void CSPI_RWDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
  USBIO_ResetDevice(byDevIndex,DEV_SPI);
  if(USBIO_SPIGetConfig(byDevIndex,&SPI_dev->byRateIndex,&SPI_dev->dwTimeout))
	UpdateController();
	
}

void CSPI_RWDlg::OnButton6() 
{
// TODO: Add your control notification handler code here
 
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
 pEdit->SetWindowText("");
 
 SPI_dev->ReadBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);


}

void CSPI_RWDlg::OnButton10() 
{
	// TODO: Add your control notification handler code here
 AboutDlg Dlg(this,byDevIndex);
 Dlg.DoModal();
	
}

void CSPI_RWDlg::OnSelchangeCombo3() 
{

 CComboBox *pbox = (CComboBox*)GetDlgItem(IDC_COMBO3);
 if(USBIO_TrigSetConfig(byDevIndex,pbox->GetCurSel()))
 {
  TRIG_dev->byRateIndex = pbox->GetCurSel();

 }
 else
 {
  MessageBox("���ô���ģʽʧ��!");
 }

}

void CSPI_RWDlg::OnCheck2() 
{
	// TODO: Add your control notification handler code here
  CButton *pbox = (CButton*)GetDlgItem(IDC_CHECK2);

	USBIO_SetCE(byDevIndex,pbox->GetCheck() == 1);

}

void CSPI_RWDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here

 if(SPI_dev->bRunning)
 {
  if(USBIO_ExitTrig(byDevIndex))
  {
	 TRIG_dev->bRunning = false;
	 SPI_dev->bRunning = false;
	 ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
     ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(true);
//     ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(true);
     ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(true);
  }

  else
	 {
	   MessageBox("�˳�����ʧ��!");
	   return;
	 }
 } 
 else
 {
  if(!USBIO_WaitForTrig(byDevIndex))
   {
	 MessageBox("��������ʧ��!");
	 return;
	}
  TRIG_dev->bRunning = true;
  SPI_dev->bRunning = true;
  ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(false);
//  ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(false);
  ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(false);

  ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("ֹͣ����");
 }	
	
}

void CSPI_RWDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
 char Buff[100]={0};
 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);
 strcpy(Buff,str.GetBuffer(str.GetLength()));
 DWORD dwReadLen = atoi(Buff);
 if(dwReadLen > 65534)
 {
	 MessageBox("���볤�Ȳ��ܴ���65534!");
	 return;
 }
 BYTE* pTmpBuff = new BYTE[dwReadLen];
 if(USBIO_SPIRead(byDevIndex,Temp,comLen,pTmpBuff,dwReadLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��ʧ��!");
	return;
 }
 SPI_dev->PutReadBuf(pTmpBuff,dwReadLen);  
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
 ApplendText(IDC_EDIT3,pTmpBuff,dwReadLen);
 delete []pTmpBuff;
}

void CSPI_RWDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }	
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
  if(SPI_dev->GetWriteCnt() > 65534)
  {
	 MessageBox("д�볤�Ȳ��ܴ���65534!");
	 return;
  }

 if(USBIO_SPIWrite(byDevIndex,Temp,comLen,(void*)SPI_dev->GetWriteBuf(),SPI_dev->GetWriteCnt())==0)
 {
	MessageBox("дʧ��!");
	return;
 }

}

bool CSPI_RWDlg::IsHexString(CString str)
{
 int len = str.GetLength();
 if(len == 0)
	return true;
 if(len % 2 || len > 256)
	return false;
 
 for(int i = 0 ; i < len ; i ++)
 {
	 if(str[i] >= '0' &&  str[i] <= '9')
		 continue;
	 else if(str[i] >= 'a' &&  str[i] <= 'f')
		 continue;
	 else if(str[i] >= 'A' &&  str[i] <= 'F')
		 continue;
	 else
		 return false;
 }
 return true;
}

void CSPI_RWDlg::StrToVal(BYTE *pByte, CString &str)
{
	int i,j;
    int len = str.GetLength()/2;
	
	for(i=0,j=0;j<len;i++,j++)
	{
		pByte[j] = (BYTE)((CharToBcd(str[i])<<4) + CharToBcd(str[i+1]));
		i++;
	}
}

void CSPI_RWDlg::VarToStr(CString &str,BYTE *pByte, int len,BYTE start)
{
 str.Empty();
 for(int i = 0 ,j = start; i < len ; i++)
 {
   str += " ";
   str += CString(BcdToChar(pByte[i] >> 4));
   str += CString(BcdToChar(pByte[i] & 0x0F));
   j += 3;
   if( j == 48)
   {
	   str += L"\r\n";
	   j = 0;
   }
 }
}


BYTE CSPI_RWDlg::BcdToChar(BYTE iBcd)
{
	BYTE hexVar[] = {"0123456789ABCDEF"};
    return hexVar[iBcd];
}

BYTE CSPI_RWDlg::CharToBcd(BYTE iChar)
{
	UCHAR	mBCD;
	if ( iChar >= '0' && iChar <= '9' ) mBCD = iChar -'0';
	else if ( iChar >= 'A' && iChar <= 'F' ) mBCD = iChar - 'A' + 0x0a;
	else if ( iChar >= 'a' && iChar <= 'f' ) mBCD = iChar - 'a' + 0x0a;
	else mBCD = 0x00;
	return( mBCD );
}


void CSPI_RWDlg::ApplendText(int id, BYTE *pByte, int len)
{
  CEdit* pEdit = (CEdit*)GetDlgItem(id);
  CString str;
  DWORD textLen = pEdit->GetWindowTextLength();
  BYTE start = textLen % 50;
  VarToStr(str,pByte,len,start);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel(str);
}

void CSPI_RWDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
   CString FileName;
   if(SPI_dev->GetReadCnt() == 0)
   {
	   MessageBox("��������Ϊ��!");
	   return;
   }
   CFileDialog* p = new CFileDialog(false,"*.bin",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName = p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}

	    CFile file(FileName,CFile::modeCreate|CFile::modeWrite);

		file.Write(SPI_dev->GetReadBuf() ,SPI_dev->GetReadCnt() );//д�ļ���־
		file.Close();
   }
   delete p;	
}

void CSPI_RWDlg::OnButton9() 
{
	// TODO: Add your control notification handler code here
   CString FileName;
   CFileDialog* p=new CFileDialog(true,"*.bin",NULL,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName=p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}
	    CFile file(FileName,CFile::modeRead);
        DWORD fileLen = file.GetLength();
		if(fileLen == 0)
		{
			delete p;
			MessageBox("�յ��ļ�!");
			return;
		}
		
		OnButton8();
		BYTE* pBuf = new BYTE[fileLen + 1];
		file.Read(pBuf,fileLen);//д�ļ���־
		SPI_dev->WriteBufUpdate(pBuf,fileLen);
		file.Close();
		delete pBuf;
		ApplendText(IDC_EDIT6,SPI_dev->GetWriteBuf(),SPI_dev->GetWriteCnt());
		char Buff[20];
		sprintf(Buff,"%08d",fileLen);
        ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
   }
   delete p;		
}

void CSPI_RWDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
 dwWriteIndex = 0;
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT6);
 pEdit->SetWindowText("");
 
 SPI_dev->WriteBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",0);
 ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
}

void CSPI_RWDlg::USB_SendData(WORD dataLen)
{
 BYTE* pBuf = SPI_dev->GetWriteBuf();
 WORD leftLen;
 DWORD dwTotalLen = SPI_dev->GetWriteCnt();
 BYTE* pTmpBuff = new BYTE[SPI_RW_SIZE];
 memset(pTmpBuff,0xFF,SPI_RW_SIZE);
 dwWriteIndex = dwWriteIndex + dataLen;
 if(dwTotalLen > dwWriteIndex)
 {
   if(dwTotalLen > dwWriteIndex + SPI_RW_SIZE)
   {
	memcpy(pTmpBuff,&pBuf[dwWriteIndex],SPI_RW_SIZE);   
   }
   else
   {
	 memcpy(pTmpBuff,&pBuf[dwWriteIndex],dwTotalLen - dwWriteIndex);
   }   

 }

 if(USBIO_SPIWrite(byDevIndex,NULL,0,pTmpBuff,SPI_RW_SIZE)==0)
 {
	MessageBox("��������ʧ��!");
 }
 delete []pTmpBuff;
}

void CSPI_RWDlg::USB_ReciData(WORD dataLen)
{
 BYTE* pTmpBuff = new BYTE[dataLen];
 BYTE temp[128] = "\r\n";
 char Buff[10];
 CString str;
 if(USBIO_SPIRead(byDevIndex,NULL,0,pTmpBuff,dataLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��������ʧ��!");
	return;
 }
 SPI_dev->PutReadBuf(pTmpBuff,dataLen);  
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
//pplendText(IDC_EDIT3,pTmpBuff,dataLen);
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
  DWORD textLen = pEdit->GetWindowTextLength();
  VarToStr(str,pTmpBuff,dataLen,0);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel("\r\n" + str);
  delete []pTmpBuff;
}

//#ifndef GUID_CLASS_COMPORT
//DEFINE_GUID(GUID_CLASS_COMPORT, 0x86e0d1e0L, 0x8089, 0x11d0, 0x9c, 0xe4, 0x08, 0x00, 0x3e, 0x30, 0x1f, 0x73);
  DEFINE_GUID(GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR, 0x4D36E978L, 0xE325, 0x11CE, 0xBF, 0xC1, 0x08, 0x00, 0x2B, 0xE1, 0x03, 0x18);
  //4D36E978-E325-11CE-BFC1-08002BE10318
//#endif
void CSPI_RWDlg::EnumPortsWdm(void)
{
	CString strErr;
	// Create a device information set that will be the container for 
	// the device interfaces.
	//GUID *guidDev = (GUID*) &GUID_CLASS_COMPORT;
    GUID *guidDev = (GUID*) &GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR;
	HDEVINFO hDevInfo = INVALID_HANDLE_VALUE;
	SP_DEVICE_INTERFACE_DETAIL_DATA *pDetData = NULL;

	try
	{
		hDevInfo = SetupDiGetClassDevs( guidDev,
			NULL,
			NULL,
			DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
			);

		if(hDevInfo == INVALID_HANDLE_VALUE) 
		{
			strErr.Format( _T("SetupDiGetClassDevs failed. (err=%lx)"),GetLastError());
			throw strErr;
		}

		// Enumerate the serial ports
		BOOL bOk = TRUE;
		SP_DEVICE_INTERFACE_DATA ifcData;
		DWORD dwDetDataSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA) + 1024;
		pDetData = (SP_DEVICE_INTERFACE_DETAIL_DATA*) new TCHAR[dwDetDataSize];
		// This is required, according to the documentation. Yes,
		// it's weird.
		ifcData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
		pDetData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
		for (DWORD ii=0; bOk; ii++) 
		{
			SP_DEVINFO_DATA DeviceInfoData={0};
			DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
			DeviceInfoData.ClassGuid = GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR;//GUID_CLASS_COMPORT;

			bOk = SetupDiEnumDeviceInfo(hDevInfo,ii,&DeviceInfoData );
			bOk = SetupDiEnumDeviceInterfaces(hDevInfo,	NULL, guidDev, ii, &ifcData);
			if (!bOk)				
			{
				DWORD nErr = GetLastError();
				if (nErr != ERROR_NO_MORE_ITEMS) 
				{
					TCHAR buf[MAX_PATH];
					FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL,nErr,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),buf,MAX_PATH,NULL);

					strErr.Format( _T("SetupDiEnumDeviceInterfaces failed. (err=%lX,%s"),nErr,buf);
					throw strErr;
				}
			}
			else
			{
				// Got a device. Get the details.
				SP_DEVINFO_DATA devdata = {sizeof(SP_DEVINFO_DATA)};
				bOk = SetupDiGetDeviceInterfaceDetail(hDevInfo,&ifcData, pDetData, dwDetDataSize, NULL, &devdata);
				if (bOk) 
				{
					CString strDevPath(pDetData->DevicePath);
					// Got a path to the device. Try to get some more info.
					TCHAR fname[256];
					TCHAR desc[256];
					TCHAR sHardID[256];
					BOOL bSuccess = SetupDiGetDeviceRegistryProperty(hDevInfo, &devdata, SPDRP_FRIENDLYNAME, NULL,(PBYTE)fname, sizeof(fname), NULL);
					bSuccess = bSuccess && SetupDiGetDeviceRegistryProperty(hDevInfo, &devdata, SPDRP_DEVICEDESC, NULL,(PBYTE)desc, sizeof(desc), NULL);
					bSuccess = SetupDiGetDeviceRegistryProperty(hDevInfo, &devdata, SPDRP_HARDWAREID, NULL,(PBYTE)sHardID, sizeof(sHardID), NULL);
					BOOL bUsbDevice = FALSE;
					TCHAR locinfo[256];
					if (SetupDiGetDeviceRegistryProperty(hDevInfo, &devdata, SPDRP_LOCATION_INFORMATION, NULL,(PBYTE)locinfo, sizeof(locinfo), NULL))
					{
						// Just check the first three characters to determine
						// if the port is connected to the USB bus. This isn't
						// an infallible method; it would be better to use the
						// BUS GUID. Currently, Windows doesn't let you query
						// that though (SPDRP_BUSTYPEGUID seems to exist in
						// documentation only).
						bUsbDevice = (_tcsncmp(locinfo, _T("USB"), 3)==0);
					}
					// Open device parameters reg key - Added after fact from post on CodeGuru - credit to Peter Wurmsdobler
					HKEY hKey = SetupDiOpenDevRegKey(hDevInfo, &devdata, DICS_FLAG_GLOBAL,0,DIREG_DEV,KEY_READ);

					TCHAR szPortName[MAX_PATH];
					if (hKey)
					{
						DWORD dwType = REG_SZ;
						DWORD dwReqSize = sizeof(szPortName);

						// Query for portname
						long lRet = RegQueryValueEx(hKey,_T("PortName"), 0, &dwType, (LPBYTE)&szPortName, &dwReqSize);
						if (lRet == ERROR_SUCCESS)
							bSuccess &= TRUE;
						else
							bSuccess &= FALSE;
					}
					else
						bSuccess &= FALSE;

					LPTSTR p = _tcsstr(sHardID,_T("VID_") );
					CString sVID,sPID;
					if( p && (p+4 < sHardID+256) )
						sVID = CString(p+4,4);
					p = _tcsstr(sHardID,_T("PID_") );
					if( p && (p+4 < sHardID+256) )
						sPID = CString(p+4,4);

					if (bSuccess
					//	&& ( ( (!lpVID) || (lpVID && sVID.CompareNoCase(lpVID)==0))  && ( (!lpPID) || (lpPID && sPID.CompareNoCase(lpPID)==0))  )
						) 
					{
						// Add an entry to the array
				/*		CComPortInfo si;
						si.strDevPath = strDevPath;
						si.strFriendlyName = fname;
						si.strPortName = szPortName;
						si.strPortDesc = desc;
						si.bUsbDevice = bUsbDevice;
						si.sVID = sVID;
						si.sPID = sPID;
						PortInfoList.push_back(si);*/
					MessageBox("find a com");	
					}

				}
				else 
				{
					DWORD nErr=GetLastError();
					TCHAR buf[MAX_PATH];
					FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL,nErr,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),buf,MAX_PATH,NULL);

					strErr.Format( _T("SetupDiGetDeviceInterfaceDetail failed:nErr=%lX,%s"),nErr,buf);
					throw strErr;
				}
			}
			
		}
	}
	catch (CString strCatchErr) 
	{
		strErr = strCatchErr;
	}

	if (pDetData != NULL)
		delete [] (TCHAR*)pDetData;
	if (hDevInfo != INVALID_HANDLE_VALUE)
		SetupDiDestroyDeviceInfoList(hDevInfo);

	if (!strErr.IsEmpty())
	{
		//throw strErr;
	//	MessageBox(NULL,strErr,NULL,MB_OK|MB_ICONERROR );
		MessageBox("error");
	}
}