
#include "stdafx.h"

#include "buff_info.h"
//------------------------------------------------------------------------------
  BuffInfo::BuffInfo()
  {
	dwReadCnt = 0;
	pReadBuf = NULL;
	dwWriteCnt = 0;
	pWriteBuf = NULL;
	pMyData = NULL;
  }
//------------------------------------------------------------------------------
  BuffInfo::~BuffInfo()
  {
	if(pReadBuf)
	  delete pReadBuf;
	if(pWriteBuf)
	  delete pWriteBuf;
	if(pMyData)
	 delete pMyData;
  }

//------------------------------------------------------------------------------
  DWORD BuffInfo::GetReadCnt()
  {
	return dwReadCnt;
  }
//------------------------------------------------------------------------------
  DWORD BuffInfo::GetWriteCnt()
  {
	return  dwWriteCnt;
  }
//------------------------------------------------------------------------------
  BYTE* BuffInfo::GetReadBuf()
  {
	return pReadBuf;
  }
//------------------------------------------------------------------------------
  BYTE* BuffInfo::GetWriteBuf()
  {
    return pWriteBuf;
  }

//------------------------------------------------------------------------------
  void BuffInfo::PutReadBuf(BYTE* pStr,DWORD dwLen)
  {
	BYTE* pNew = new BYTE[dwReadCnt+dwLen];
	memcpy(pNew,pReadBuf,dwReadCnt);
	memcpy(&pNew[dwReadCnt],pStr,dwLen);
	dwReadCnt = dwReadCnt+dwLen;
	delete pReadBuf;
	pReadBuf = pNew;
  }
//------------------------------------------------------------------------------
  void BuffInfo::WriteBufUpdate(BYTE* pStr,DWORD dwLen)
  {
	delete pWriteBuf;
	pWriteBuf = new BYTE[dwLen];
	memcpy(pWriteBuf,pStr,dwLen);
	dwWriteCnt = dwLen;
  }
//------------------------------------------------------------------------------
  void BuffInfo::ReadBufClear()
  {
   delete pReadBuf;
   pReadBuf = NULL;
   dwReadCnt = 0;
  }

  //------------------------------------------------------------------------------
  void BuffInfo::WriteBufClear()
  {
   delete pWriteBuf;
   pWriteBuf = NULL;
   dwWriteCnt = 0;
  }

 void* BuffInfo::GetData()
 {
   return pMyData;
 }

 void  BuffInfo::SetData(void* pData)
 {
   if(pMyData)
   {
	 delete pMyData;
   }
   pMyData = pData;
 }



