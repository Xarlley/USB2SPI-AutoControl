// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPI_RW.h"
#include "AboutDlg.h"
#include "M3F20xm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AboutDlg dialog


AboutDlg::AboutDlg(CWnd* pParent /*=NULL*/,BYTE id)
	: CDialog(AboutDlg::IDD, pParent)
{
	bIndex = id;
	//{{AFX_DATA_INIT(AboutDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void AboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AboutDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(AboutDlg, CDialog)
	//{{AFX_MSG_MAP(AboutDlg)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &AboutDlg::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AboutDlg message handlers

BOOL AboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
 char ver[100];
 memset(ver,0,100);
 strcat(ver,"SPI_RW_APP_03;");
 strcat(ver,__DATE__);
 strcat(ver," ");
 strcat(ver,__TIME__);


 ((CStatic*)GetDlgItem(IDC_STATIC_APP))->SetWindowText(ver);
 if(M3F20xm_GetVersion(bIndex,0,ver))
 {
 ((CStatic*)GetDlgItem(IDC_STATIC_DLL))->SetWindowText(ver);
 }
 memset(ver,0,100);
 if(M3F20xm_GetVersion(bIndex,1,ver))
 {
 ((CStatic*)GetDlgItem(IDC_STATIC_SYS))->SetWindowText(ver);
 }
 memset(ver,0,100);
 if(M3F20xm_GetVersion(bIndex,2,ver))
 {
 ((CStatic*)GetDlgItem(IDC_STATIC_FW))->SetWindowText(ver);
 }

 return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void AboutDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialog::OnOK();
}
